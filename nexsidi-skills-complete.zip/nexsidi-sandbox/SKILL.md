---
name: nexsidi-sandbox
description: Use when implementing or modifying code execution isolation, the command allowlist, or sandbox boundaries — Patent Claim 5.
---

# NexSidi Sandbox — Patent Claim 5
## Two Real Anthropic Approaches, One Architecture Decision

## ⚠️ Patent Claim Warning

This implements Patent Claim 5 (4-tier kernel isolation). Read fully
before modifying. Ask Amit before changing the isolation architecture
itself — the additions below are validated against official Anthropic
sources but the underlying patent claim language is fixed.

## What Anthropic Actually Uses (not Docker)

From "Beyond Permission Prompts: Making Claude Code More Secure and
Autonomous" (official, read in full): Anthropic's own sandboxing is
**bubblewrap (Linux) + seatbelt (macOS)** at the OS level — explicitly
NOT Docker containers. Two boundaries:

1. **Filesystem isolation** — read/write restricted to the current
   working directory only
2. **Network isolation** — only via a unix domain socket through a
   proxy that enforces domain allowlists

Open source at `github.com/anthropic-experimental/sandbox-runtime`.

**This is lighter-weight than NexSidi's current Rust 4-tier Docker
design** (namespaces + cgroups v2 + seccomp-bpf + iptables) — no
container startup overhead, no image management. Worth a deliberate
comparison, not an assumed replacement: NexSidi's adversarial QA needs
to run untrusted, freshly-generated application code (full dev servers,
arbitrary dependencies) — a heavier guarantee than Claude Code's own
use case of running trusted tool calls in a known project directory.
**Recommendation: keep the Docker-based 4-tier design for executing
GENERATED user code (Navya/Karan/Deepika's live testing), but adopt the
bubblewrap/seatbelt pattern for NexSidi's OWN agent tool execution**
(file reads, git operations, package installs during generation) where
the lighter guarantee is sufficient and the startup speed matters more.

## Real Command Allowlist (verbatim, from Anthropic's own autonomous
coding demo — `claude-quickstarts/autonomous-coding/security.py`)

```python
ALLOWED_COMMANDS = {
    # File inspection
    "ls", "cat", "head", "tail", "wc", "grep",
    # File operations (agent uses SDK tools for most ops; cp/mkdir occasionally needed)
    "cp", "mkdir", "chmod",  # chmod validated separately, see below
    "pwd",
    # Node.js development
    "npm", "node",
    # Version control
    "git",
    # Process management
    "ps", "lsof", "sleep", "pkill",  # pkill validated separately
    # Script execution
    "init.sh",  # validated separately
}

COMMANDS_NEEDING_EXTRA_VALIDATION = {"pkill", "chmod", "init.sh"}
```

This is the real, minimal set Anthropic itself ships for an autonomous
coding agent. **NexSidi's TypeScript port for Shubham/Pranav/Riya's
`run_command` tool (see `nexsidi-agent-tools`) should use this exact
list as the baseline**, extended only as specifically needed per agent.

## Compound Command Parsing (closes the allowlist bypass gap)

A naive allowlist checking only the first word lets `ls && rm -rf /`
through because `ls` is allowed. The real implementation splits and
validates EVERY segment:

```python
def split_command_segments(command_string: str) -> list[str]:
    # Splits on && and || (not inside quotes), then further on ;
    segments = re.split(r"\s*(?:&&|\|\|)\s*", command_string)
    result = []
    for segment in segments:
        sub_segments = re.split(r'(?<!["\'])\s*;\s*(?!["\'])', segment)
        result.extend(s.strip() for s in sub_segments if s.strip())
    return result

def extract_commands(command_string: str) -> list[str]:
    # Uses shlex.split per segment — fails CLOSED (blocks) on malformed
    # quotes rather than guessing. Skips shell keywords (if/then/for/
    # while/etc), skips flags (-x), skips VAR=value assignments. Extracts
    # base command name even from full paths (/usr/bin/python -> python).
```

**Fail-safe principle:** malformed/unparseable commands return an empty
list, which the caller treats as a block, never an allow. NexSidi's
TypeScript port must preserve this fail-closed behavior exactly.

## Per-Command Extra Validation (the 3 commands needing more than allowlist membership)

```python
# pkill — only dev-related process names, smart -f flag handling
ALLOWED_PKILL_TARGETS = {"node", "npm", "npx", "vite", "next"}
# "pkill -f 'node server.js'" -> target extracted as "node" (first word), validated

# chmod — ONLY +x variants permitted, via strict regex
# Matches: +x, u+x, g+x, o+x, a+x, ug+x — rejects ANY other mode, rejects -R entirely
import re
ALLOWED_CHMOD_MODE = re.compile(r"^[ugoa]*\+x$")

# init.sh — only ./init.sh specifically, not any arbitrary script named init.sh
```

## Hook Wiring (Agent SDK pattern — Python equivalent of Claude Code's hooks.json)

```python
security_settings = {
    "permissions": {
        "defaultMode": "acceptEdits",  # auto-approve file edits WITHIN the project dir
        "allow": [ ... ],  # explicit tool allowlist
    },
}
# PreToolUse hook matcher — exact integration point:
# "PreToolUse": [HookMatcher(matcher="Bash", hooks=[bash_security_hook])]
```

**NexSidi's TypeScript equivalent:** this is the same shape as
`nexsidi-agent-tools`'s `executeToolCall` → `validateScope` flow. The
`run_command` tool definition there should call a TypeScript port of
this exact validation chain before any shell execution reaches the
sandbox.

## What This Skill Forbids

1. Using Docker for NexSidi's own lightweight agent tool execution where
   bubblewrap/seatbelt-equivalent isolation would suffice (startup cost)
2. Allowlist checking only the first word of a compound command
3. Allowing chmod with any mode other than `+x` variants, or with `-R`
4. Allowing pkill against any process name outside the dev-process set
5. Treating a malformed/unparseable command as anything other than a block

---
*Source: claude.com/blog "Beyond Permission Prompts" (official, full
read) + anthropics/claude-quickstarts autonomous-coding/security.py
(official, full read — every validation function).*
