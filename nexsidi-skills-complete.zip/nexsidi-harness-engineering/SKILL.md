---
name: nexsidi-harness-engineering
description: Use when designing or modifying how NexSidi agents call tools, defining new tool schemas, improving agent recovery from errors, auditing the harness for unnecessary complexity, or evaluating whether a harness component is still load-bearing.
allowed-tools:
  - Read
  - Bash
  - Edit
---

# NexSidi Harness Engineering — Action Space, Observation Design, Re-Simplify
## Source: ECC `agent-harness-construction/SKILL.md` + `autonomous-agent-harness/SKILL.md` + D27

## The Four Quality Constraints (ECC source, verbatim)

Agent output quality is constrained by exactly four things:
1. **Action space quality** — what tools the agent can call
2. **Observation quality** — what the tool responses look like
3. **Recovery quality** — what happens when things fail
4. **Context budget quality** — how much context is consumed per turn

Improving any one of these improves agent performance without changing
the model. Improving all four is the harness engineering job.

---

## 1. Action Space Design

**Stable, explicit tool names.** Don't rename tools that agents already
know — they're effectively API contracts.

**Schema-first, narrow inputs.** Every tool parameter should have an
exact type and validation. Catch bad inputs at the harness boundary,
never inside the tool's execution path.

**Deterministic output shapes.** If a tool returns different shapes
depending on conditions, agents can't reliably parse it. Pick one shape.

**No catch-all tools unless isolation is impossible.** A tool called
`run_anything(command: string)` is a security boundary failure and a
harness quality failure simultaneously.

### Granularity Rules

| When to use | Tool type | Examples |
|---|---|---|
| High-risk operations (deploy, migrate, delete) | Micro-tools — one action only | `deploy_to_staging`, `run_migration`, `delete_sandbox` |
| Common loops (edit, read, search) | Medium tools — a few related actions | `write_file`, `read_file`, `search_codebase` |
| Round-trip overhead is dominant cost | Macro-tools — batched actions | `setup_project_environment` (combines install + config) |

NexSidi-specific application — the permission harness (nexsidi-sandbox)
already enforces this via risk classes (READ / DRAFT / WRITE / EXTERNAL
/ DESTRUCTIVE / PRIVILEGED). Align tool granularity with risk class:
DESTRUCTIVE and PRIVILEGED tools must be micro-tools by definition.

---

## 2. Observation Design

Every tool response must include exactly these four fields:

```typescript
interface ToolResponse {
  status: 'success' | 'warning' | 'error';
  summary: string;         // one-line result — what happened
  next_actions: string[];  // actionable follow-ups the agent should consider
  artifacts: string[];     // file paths / IDs / URLs produced
}
```

**Why `next_actions` matters:** an agent that receives `status: error`
with no `next_actions` will either hallucinate a fix or retry
identically. `next_actions` breaks the loop by giving the agent a
concrete path forward.

**Why `artifacts` matters:** without file paths, agents inline large
outputs into context (the context overloading anti-pattern below).
A path reference costs ~20 tokens; the file contents cost thousands.

---

## 3. Error Recovery Contract

For every error path, the tool response must include:

```typescript
interface ErrorResponse extends ToolResponse {
  status: 'error';
  rootCauseHint: string;      // why this likely failed
  safeRetryInstruction: string; // what to try differently
  stopCondition: string;       // when to stop retrying and escalate
}
```

**NexSidi escalation path:** when a tool's `stopCondition` is reached,
the agent escalates to Tilotma. Tilotma either resolves or presents
one specific question to Amit — never swallows the error.

---

## 4. Context Budget Management (D13 applied at harness level)

```
Rule 1: Keep system prompt minimal and invariant.
        Skills load additional context on demand — system prompt is ROM.

Rule 2: Move large guidance into skills loaded on demand.
        Don't inline a 2,000-word reference guide in every agent prompt.

Rule 3: Prefer references to files over inlining documents.
        Return file paths from tools; let the agent Read them if needed.

Rule 4: Compact at phase boundaries, not arbitrary token thresholds.
        A good phase boundary in the NexSidi pipeline: after spec lock,
        after parallel build completes, after adversarial QA passes.
```

---

## 5. Architecture Pattern — Hybrid (ECC Recommended)

```
ReAct (reasoning + acting) — best for exploratory tasks
Function-calling — best for structured deterministic flows
Hybrid (recommended for NexSidi): ReAct planning + typed tool execution
```

NexSidi agents use structured typed outputs (Zod schemas on responses)
for their tool calls, but use ReAct-style reasoning in their system
prompts when they need to plan multi-step sequences. The two modes
are not mutually exclusive.

---

## 6. Re-Simplify Discipline (D27 — Critical)

> "Harness complexity should shrink as models improve. NexSidi must
> have an explicit mechanism to re-evaluate whether each harness
> component is still load-bearing as better models arrive."

**What this means in practice:** After every significant model upgrade
(DeepSeek V5, Kimi K3, etc.), run this audit on the harness:

```markdown
## Harness Audit — [Model Upgrade Date]

For each harness component, answer:
1. What problem was this solving?
2. Does the new model still need this, or does it handle it natively?
3. If native: remove the component and verify output quality holds.
4. If still needed: document why.

Components reviewed this cycle:
- [ ] Stuck-detection logic (3-iteration window)
- [ ] Context compaction at phase boundaries
- [ ] Observation `next_actions` field (new model may infer better)
- [ ] Granularity of micro vs. medium tools
- [ ] Error recovery contract detail level
```

**The rule:** parts of the harness added for an older model's
limitations are overhead for a newer model. Build for modularity,
not permanence. Complexity that can't be justified by current model
behavior is debt.

---

## Benchmarking — What to Track

```typescript
interface HarnessMetrics {
  completionRate: number;    // % of tasks that complete successfully
  retriesPerTask: number;    // average retries before success
  passAt1: number;           // % passing on first attempt
  passAt3: number;           // % passing within 3 attempts
  costPerTask: number;       // token cost per successful completion
}
```

If `retriesPerTask` is rising after a model upgrade, the harness
may be over-constraining the newer model. Check the re-simplify
audit — some component may now be causing the agent to retry rather
than enabling it.

## Harness Anti-Patterns

| Anti-Pattern | Impact | Fix |
|---|---|---|
| Too many tools with overlapping semantics | Agent picks wrong tool, retries | Audit and merge overlapping tools |
| Opaque tool output with no recovery hints | Agent hallucinates fixes | Add `rootCauseHint` + `next_actions` |
| Error-only output without next steps | Retry loops | Every error response needs a stop condition |
| Context overloading with irrelevant references | Pushes relevant context out of window | File paths, not inlined content |
| Complexity justified by an older model | Unnecessary overhead | Run re-simplify audit after model upgrade |

---
*Source: ECC `skills/agent-harness-construction/SKILL.md` (action space,
observation design, error recovery, context budgeting, benchmarking) and
`skills/autonomous-agent-harness/SKILL.md` (architecture patterns).
NexSidi D27 (re-simplify discipline), D13 (context budget), and the
permission harness risk classes applied from CLAUDE.md.*
