---
name: nexsidi-unattended-loop
description: Use when designing or implementing the outer harness that runs NexSidi's generator agents across many unattended sessions without a human manually restarting each one — the mechanism that sits ABOVE per-session workflow.
allowed-tools:
  - Read
  - Bash
---

# NexSidi Unattended Loop — Real ralph-loop Pattern
## Official Anthropic Source: claude-quickstarts/autonomous-coding

## What This Skill Covers (and how it relates to nexsidi-master-workflow)

`nexsidi-master-workflow` defines what happens **inside one session** —
read `PROGRESS.md`, work one item, verify with evidence, hand off
cleanly. It assumes something (a human, or a script) starts that
session.

**This skill is that something.** It's the outer mechanism: a loop that
runs session after session unattended, with a fresh context window each
time, auto-continuing until the work is done or a cap is hit. This was
previously an unbuilt pattern — 0 of 4 purple-tier harness patterns had
a dedicated skill. Source: `claude-quickstarts/autonomous-coding`
(official Anthropic repo), `agent.py` + `progress.py` + the two prompt
files, all read in full.

## The Real Outer-Loop Mechanics (verbatim structure)

```python
iteration = 0
while True:
    iteration += 1
    if max_iterations and iteration > max_iterations:
        break  # stop, don't crash — print resume instructions

    client = create_client(project_dir, model)  # FRESH context every time
    prompt = get_initializer_prompt() if is_first_run else get_coding_prompt()

    async with client:
        status, response = await run_agent_session(client, prompt, project_dir)

    if status == "continue":
        await asyncio.sleep(AUTO_CONTINUE_DELAY_SECONDS)  # 3s, not instant —
        # gives a human watching logs a window to Ctrl+C before the next session fires
    elif status == "error":
        await asyncio.sleep(AUTO_CONTINUE_DELAY_SECONDS)
        # retries with a fresh session rather than crashing the whole loop
```

**Session-length cap, real mechanism:** `max_turns=1000` set on the
client options — this is the actual "cap session length" half of the
pattern. It's not a token budget or a wall-clock timer; it's a hard
turn-count ceiling per session, forcing a clean handoff before the
agent runs unboundedly inside one context window.

**Resumability is structural, not a separate feature:** the loop checks
for the existence of the progress-tracking file
(`feature_list.json` in source; NexSidi's equivalent is `PROGRESS.md`
plus whatever structured test-status file the harness uses) to decide
initializer-vs-continuation on every single startup — including a
human-interrupted Ctrl+C resume. Re-running the exact same command after
an interrupt is the resume mechanism; there is no separate "resume" flag.

## The Append-Only Invariant — Stricter Than Master-Workflow's Current Rule

**Real source rule, exact wording:** "IT IS CATASTROPHIC TO REMOVE OR
EDIT FEATURES IN FUTURE SESSIONS. Features can ONLY be marked as
passing... Never remove features, never edit descriptions, never modify
testing steps."

This is a **stricter, more specific invariant** than what
`nexsidi-master-workflow` currently states. That skill covers evidence-
before-passing; it does not yet explicitly forbid an agent from quietly
deleting or rewriting a failing test/feature entry to make progress
look better than it is. **Recommend folding this exact invariant into
whatever structured progress/test file NexSidi's harness uses**: only
one field (`passes` / equivalent) may ever be mutated by a coding-
session agent; structure, descriptions, and step lists are write-once.

## Mandatory Regression Check Before New Work — Also a Gap to Close

**Real source rule, Step 3 of the coding prompt, verbatim intent:**
before implementing anything new, re-run 1-2 of the features already
marked passing to confirm the previous session didn't silently break
them. If any issue is found — functional OR visual (the source lists
white-on-white text, layout overflow, console errors as real examples
caught this way) — mark that feature failing again immediately and fix
it before starting new work.

This is a **forward-AND-backward check**, where `nexsidi-master-
workflow`'s current "Proof Before Passing" is forward-only (verify the
NEW thing works). **Recommend adding an explicit regression step** at
the start of every NexSidi unattended session, not just at the end.

## Real-User-Behavior Testing Discipline (the DON'Ts are as load-bearing as the DOs)

```
DO:  test through the UI with actual clicks and keyboard input
DO:  take screenshots to verify visual appearance
DO:  check for console errors
DON'T: only test with curl (backend-only testing is insufficient)
DON'T: use JS evaluation to bypass the UI as a shortcut
DON'T: skip visual verification because the API response looked right
```

The explicit DON'Ts matter because they're the exact shortcuts an
unattended agent under turn-budget pressure will reach for first — this
is precisely where session-cap pressure (the 1000-turn ceiling) creates
an incentive to cut corners, so the prohibition has to be explicit, not
implied.

## How the Loop Composes With NexSidi's Existing Harness

```
nexsidi-unattended-loop      →  outer process: fresh session, repeat until done/capped
  └─ nexsidi-master-workflow →  inside each session: read handoff, one item, verify, hand off
       └─ nexsidi-adversarial-qa  →  Generator/Evaluator harness for the code itself
            └─ nexsidi-sandbox    →  command allowlist + OS-level isolation (already covers
                                       the defense-in-depth security model this source also uses —
                                       no new sandbox content needed here, just confirmed consistent)
```

## Context Reset vs Compaction — Model-Dependent (Critical Update)

These are two different mechanisms. Know which one applies:

**Compaction:** Earlier parts of the conversation are summarized
in place. The SAME agent continues on a shortened history.
Preserves continuity. Does NOT give a clean slate — context anxiety
can still persist.

**Context Reset:** The context window is cleared entirely. A FRESH
agent starts with a structured handoff artifact carrying the previous
agent's state and next steps. Gives a clean slate. Adds orchestration
complexity, token overhead, and latency per reset.

**Which to use:**
- Sonnet 4.5 era → context resets were ESSENTIAL. Sonnet 4.5 exhibited
  "context anxiety" strongly enough that compaction alone failed.
- Opus 4.6 era → automatic compaction via the Agent SDK is sufficient.
  Opus 4.6 largely removed context anxiety on its own. Context resets
  are no longer load-bearing for most tasks.

**NexSidi today runs Opus-tier models (DeepSeek V4-Pro, MiniMax M3,
Mistral Nemotron, Kimi K2.6).** These do not exhibit Sonnet 4.5-era
context anxiety. Use Agent SDK automatic compaction. Reserve context
resets for tasks that demonstrably fail with compaction alone — don't
add reset overhead pre-emptively.

Source: Anthropic Mar 2026 harness blog: "Opus 4.5 largely removed
that behavior on its own, so I was able to drop context resets from
this harness entirely. The agents were run as one continuous session
across the whole build, with the Claude Agent SDK's automatic
compaction handling context growth along the way."

## Agent SDK — Use This, Not Raw SDK

The Claude Agent SDK (`@anthropic-ai/claude-agent-sdk`) handles
automatic compaction and is the orchestration tool used in Anthropic's
own harnesses. Use it instead of raw `@anthropic-ai/sdk` for the
outer loop. Update `nexsidi-llm-client` if switching from raw SDK.

## What This Skill Forbids

1. Letting a coding-session agent edit or remove an existing progress/
   feature-list entry — only the pass/fail field may ever change
2. Starting new feature work before re-verifying 1-2 previously-passing
   features in the same session
3. Marking anything "passing" based on curl/API-only testing or JS-
   evaluation shortcuts when a UI exists to test through
4. An unbounded session with no turn cap — every unattended session
   needs an explicit ceiling, not an implicit "until it stops"
5. Treating a Ctrl+C interrupt as requiring special resume logic — the
   same start command must be naturally resumable by checking for the
   existing progress file

---
*Source: `claude-quickstarts/autonomous-coding` (official Anthropic
repo) — `agent.py`, `progress.py`, `client.py`, `security.py`,
`prompts/initializer_prompt.md`, `prompts/coding_prompt.md`, all read
in full.*
