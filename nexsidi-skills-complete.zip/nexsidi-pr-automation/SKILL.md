---
name: nexsidi-pr-automation
description: Use when setting up or modifying Karan's automated PR review gate in GitHub Actions, or when adding any Claude-powered CI automation to the NexSidi pipeline.
allowed-tools:
  - Read
  - Write
  - Bash
---

# NexSidi PR Automation — Karan's CI Gate via claude-code-action
## Source: anthropics/claude-code-action (full README + docs read)

## What This Is

Karan's PR review gate is not something NexSidi needs to build from
scratch. The official `anthropics/claude-code-action` GitHub Action
IS Karan's automated review — production-ready, MIT licensed, runs on
your own GitHub runner, no new infrastructure needed.

```
Shubham/Aanya/Pranav push code
  → git push → GitHub PR opened
    → claude-code-action triggers automatically
      → Karan (Claude Code) reviews the diff
        → Posts findings as PR review comment
          → NexSidi CI passes/fails based on findings
```

## Core Workflow — Karan's Security + Quality Review

```yaml
# .github/workflows/karan-pr-review.yml
name: Karan — PR Review Gate

on:
  pull_request:
    types: [opened, synchronize]

jobs:
  karan-review:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      pull-requests: write

    steps:
      - uses: anthropics/claude-code-action@v1
        with:
          prompt: |
            You are Karan, NexSidi's adversarial code reviewer.
            Review this PR diff with high skepticism.

            CHECK FOR:
            1. Security vulnerabilities (OWASP Top 10, injection,
               auth bypasses, exposed secrets)
            2. TypeScript/Bun/Hono conventions (NexSidi API layer)
            3. Next.js 14 App Router patterns (generated app frontend)
            4. Drizzle ORM patterns — no raw SQL strings
            5. RLS enabled on all new Supabase tables
            6. Expand-contract migration pattern (no rename/drop in one step)
            7. Test coverage — every new function has a test
            8. No agent names, agent count, or internal architecture
               in any user-facing output

            SEVERITY RATINGS (required for every finding):
            - CRITICAL: Blocks merge. Security breach or data loss risk.
            - HIGH: Must fix before merge. Significant quality or security issue.
            - MEDIUM: Should fix. Meaningful quality concern.
            - LOW: Optional improvement.

            END with: MERGE_READY or CHANGES_REQUIRED
          anthropic_api_key: ${{ secrets.ANTHROPIC_API_KEY }}
```

## Path-Specific Triggers — Only Review Critical File Changes

```yaml
# Trigger only when API, DB, or auth files change
on:
  pull_request:
    paths:
      - "src/api/**/*.ts"
      - "src/db/**/*.ts"
      - "src/middleware/auth.ts"
      - "src/agents/**/*.ts"
```

## Security-Focused Review (Vikram/Priya — Red Team in CI)

```yaml
- uses: anthropics/claude-code-action@v1
  with:
    prompt: |
      Security-focused review of PR #${{ github.event.pull_request.number }}.

      Focus exclusively on:
      - SQL injection / NoSQL injection risks
      - XSS vulnerabilities in any user-facing output
      - Authentication bypasses (Clerk JWT validation gaps)
      - Exposed secrets or credentials in code
      - SSRF risks in any URL-fetching code
      - Input sanitization gaps (Layer 1 of NexSidi security model)
      - RLS gaps on Supabase tables

      Rate each finding: Critical / High / Medium / Low
    anthropic_api_key: ${{ secrets.ANTHROPIC_API_KEY }}
    claude_args: |
      --model claude-sonnet-4-6
      --max-turns 10
```

## Interactive Mode — @karan Mentions in PR Comments

Without a `prompt` input, the action runs in interactive mode —
any PR comment containing @claude (or configure to respond to @karan)
triggers a response:

```yaml
on:
  issue_comment:
    types: [created]
  pull_request_review_comment:
    types: [created]

steps:
  - uses: anthropics/claude-code-action@v1
    with:
      # No prompt = interactive mode
      # Responds to @claude mentions in comments
      anthropic_api_key: ${{ secrets.ANTHROPIC_API_KEY }}
```

## Key Technical Facts

- **Runs on your GitHub runner** — Anthropic API calls leave your runner
  to Anthropic's servers, but execution is on your own infra
- **Automatic mode detection** — with `prompt` = automation mode,
  without = interactive mode (@mention response)
- **No tracking comments in automation mode** — add `track_progress: true`
  if you want progress indicators
- **Authentication** — `ANTHROPIC_API_KEY` secret in GitHub repo settings.
  Also supports AWS Bedrock, Google Vertex AI for enterprise isolation.

## Install in 2 Minutes

```bash
# From Claude Code terminal:
/install-github-app
# Guides through GitHub app setup + secret creation
# Must be repo admin
```

## What This Skill Is NOT For

- Code execution inside the sandbox (that's `nexsidi-sandbox`)
- The adversarial QA scoring loop (that's `nexsidi-adversarial-qa`)
- Post-deployment security monitoring (that's `nexsidi-security` Blue Team)

This skill is specifically the CI/CD gate — PR review that runs
automatically on every push, before anything merges to main.

---
*Source: anthropics/claude-code-action (README, docs/custom-automations.md,
docs/security.md, docs/configuration.md) — all read in full.
NexSidi agent assignments and security model applied from CLAUDE.md.*
