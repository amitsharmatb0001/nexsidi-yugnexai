---
name: nexsidi-frontend
description: Use when writing, reviewing, or generating any Next.js 16 App Router code, for NexSidi's own platform frontend or for any code an agent generates for a user.
---

# Next.js 14 — General Capability + NexSidi Application
## Fixes the original scoping bug: broad framework knowledge first, project examples second

## Why This Was Rewritten

The prior version of this skill taught Next.js 14 only through NexSidi's
own narrow MVP examples (pipeline dashboard, planning chat UI). Outside
that scope, the skill contained nothing — Claude had zero general Next.js
14 knowledge to draw on. This version inverts that: broad, structured
framework knowledge first (sourced from a real 52-row guideline database
covering 14 categories with official Next.js docs links), NexSidi's
specific application as a clearly separated section at the end.

## Core Guidelines By Category (general — applies to ANY Next.js 14 project)

### Routing
| Guideline | Severity | Do | Don't |
|---|---|---|---|
| Use App Router for new projects | Medium | `app/` directory with `page.tsx` | `pages/` for new projects |
| Use file-based routing | Medium | `page.tsx` for routes, `layout.tsx` for layouts | Manual route configuration |
| Colocate related files | Low | Component files alongside `page.tsx` | Separate components folder |
| Use route groups for organization | Low | `(marketing)/about/page.tsx` | `marketing/about/page.tsx` (affects URL) |
| Handle loading states | Medium | `loading.tsx` alongside `page.tsx` | Manual loading state via useState |
| Handle errors with error.tsx | **High** | `error.tsx` with reset function | try/catch in every component |

### Rendering (the highest-severity category — most "High" ratings)
| Guideline | Severity | Do | Don't |
|---|---|---|---|
| Use Server Components by default | **High** | Keep components server by default | Add `'use client'` unnecessarily |
| Mark Client Components explicitly | **High** | `'use client'` only when needed (hooks/events) | Server Component with hooks/events |
| Push Client Components down | **High** | Client wrapper for interactive parts only | Mark entire page as Client Component |
| Use streaming for better UX | Medium | `<Suspense>` for slow data fetches | Wait for all data before render |
| Choose correct rendering strategy | Medium | SSG for static, SSR for dynamic, ISR for semi-static | SSR for content that's actually static |

### Data Fetching
| Guideline | Severity | Do | Don't |
|---|---|---|---|
| Fetch data in Server Components | **High** | `async function Page() { const data = await fetch() }` | `useEffect` for initial data |
| Configure caching explicitly (Next 15+) | **High** | `fetch(url, { cache: 'force-cache' })` explicitly | Assume default is cached — it isn't in v15 |
| Deduplicate fetch requests | Low | Same fetch call across components — React dedupes automatically | Manual request deduplication layer |
| Use Server Actions for mutations | Medium | `<form action={serverAction}>` | API route for every mutation |
| Revalidate data appropriately | Medium | `revalidatePath('/posts')` after mutation | `router.refresh()` everywhere |

### Images
| Guideline | Severity | Do | Don't |
|---|---|---|---|
| Use next/image for optimization | **High** | `<Image>` component for all images | Raw `<img>` tags directly |
| Provide width and height | **High** | Explicit `width`/`height` or `fill` | Missing dimensions (causes layout shift) |
| Use fill for responsive images | Medium | `fill` prop with relative parent | Fixed dimensions for responsive images |

*(Full 52-row guideline set covers API, Config, Deployment, Environment,
Fonts, Link, Metadata, Middleware, Performance, Security as additional
categories — query the source CSV for the complete set when a specific
category isn't covered above.)*

## NexSidi-Specific Application (separated, not blended)

This is what Aanya actually builds — it assumes and depends on the
general knowledge above, never replaces it.

```
generated-project/                    [for user-facing generated apps]
├── app/
│   ├── layout.tsx
│   ├── page.tsx
│   ├── (auth)/login/page.tsx
│   ├── dashboard/page.tsx
│   └── api/
├── components/ui/                    [shadcn/ui]
└── lib/api-client.ts                 [talks to Express backend, see nexsidi-generated-stack]
```

**For NexSidi's own platform UI** (pipeline dashboard, planning chat) —
see `nexsidi-streaming` for the WebSocket status integration and
`nexsidi-master-workflow` for the PROGRESS.md-driven session conventions.

Design tokens for either context come from Vanya querying the real
uipro-cli database (see `nexsidi-ui-ux`) — never invented inline.

## What This Skill Forbids

1. Defaulting to Client Components without a specific interactivity need
   (violates the "High" severity Rendering guidelines above)
2. Fetching data via `useEffect` in a Server Component context
3. Using raw `<img>` tags instead of `next/image`
4. Assuming Next.js 15+ fetch caching defaults without setting explicitly
5. Teaching only NexSidi's specific examples without the general
   guideline table above as the foundation

---
*Source: ui-ux-pro-max-skill's stacks/nextjs.csv — 52 real guidelines
across 14 categories with official Next.js docs links, read in full.
Fixes the general/specific scoping bug identified earlier this session.*
