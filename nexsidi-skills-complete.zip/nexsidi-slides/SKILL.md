---
name: nexsidi-slides
description: Use when creating pitch decks, investor presentations, product demos, or any multi-slide HTML presentation for YugNex/NexSidi.
allowed-tools:
  - Bash
  - Read
---

# NexSidi Slides — Strategic HTML Presentations
## Source: ui-ux-pro-max `.claude/skills/slides/SKILL.md` + `design-system/SKILL.md` (slide section)

## Core Rule — Slides Are HTML, Not PowerPoint

All NexSidi presentations are HTML files using:
- `assets/design-tokens.css` — single source of truth for all colors/fonts
- Chart.js for all data visualizations (NOT CSS-only bar charts)
- Keyboard arrow navigation + progress bar
- Brand tokens via CSS variables (never hardcoded hex)

## Slide Search (BM25 Database)

```bash
# Find slide strategies for a specific goal
python scripts/search-slides.py "investor pitch saas"

# Domain-specific
python scripts/search-slides.py "problem agitation" -d copy
python scripts/search-slides.py "revenue growth" -d chart

# Contextual (position-aware recommendations)
python scripts/search-slides.py "problem slide" --context --position 2 --total 9
python scripts/search-slides.py "cta" --context --position 9 --prev-emotion frustration
```

## Decision System — What Gets Selected Per Slide

```
1. Goal → search slide-strategies.csv → strategy + emotion arc
2. Per slide:
   a. slide-layout-logic.csv → layout + pattern-break flag
   b. slide-typography.csv → type scale
   c. slide-color-logic.csv → color treatment by emotion
   d. slide-backgrounds.csv → image category if needed
   e. slide-animations.css → animation class
3. Generate HTML with design tokens
```

## Mandatory Slide Requirements

Every slide MUST:
1. Import `assets/design-tokens.css` — no exceptions
2. Use CSS variables: `var(--color-primary)`, `var(--slide-bg)`, etc.
3. Use Chart.js for any chart (not CSS-only)
4. Include keyboard navigation + progress indicator
5. Center-align content
6. Focus on persuasion — not just information dump

## NexSidi Pitch Deck Constraints

**Confidentiality rule applies to every slide:**
- No agent names, no agent count, no internal architecture
- "Coordinated multi-agent system" ✅
- "12 specialized agents called Tilotma/Shubham/Aanya" ❌

**Technical depth ceiling = 10 patent claims**
Slides may describe what the patent claims without revealing how the
system is internally structured beyond what the claims already disclose.

**Framing: category creator, not Indian startup**
India/Bhilwara/cost-arbitrage narrative is explicitly removed.
Positioning: global AI coding platform, autonomous software lifecycle.

**Valuation context (verify against nexsidi-cfo before any slide):**
$1.0M / 15% / $5.67M pre-money — reconcile with live numbers before
any deck that includes financial figures.

## Duarte Sparkline — Pattern Breaking for Engagement

Premium decks alternate between emotional states:
```
"What Is" (frustration/pain) ↔ "What Could Be" (hope/solution)
```
Pattern breaks at 1/3 and 2/3 positions of the deck. The slide
search's `--context` flag uses `--prev-emotion` to calculate this
automatically.

## HTML Chart.js Template

```html
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<canvas id="revenueChart"></canvas>
<script>
new Chart(document.getElementById('revenueChart'), {
    type: 'line',
    data: {
        labels: ['Q1', 'Q2', 'Q3', 'Q4'],
        datasets: [{
            data: [0, 5, 28, 120],
            borderColor: 'var(--color-primary)',
            backgroundColor: 'rgba(var(--color-primary-rgb), 0.1)',
            fill: true,
            tension: 0.4
        }]
    }
});
</script>
```

---
*Source: ui-ux-pro-max `.claude/skills/slides/SKILL.md` and the slide
section of `.claude/skills/design-system/SKILL.md`, both read in full.
NexSidi confidentiality and framing rules from CLAUDE.md.*
