---
name: nexsidi-session-memory
description: Use when an agent needs to recall context from a previous session, search past pipeline decisions, or record an architectural decision for future retrieval.
---

# NexSidi Session Memory — claude-mem MCP Integration

## Real Tool Interface (exact, from claude-mem's actual mcp/tools.ts)

Six MCP tools, exact schemas — not a "3-layer search workflow" as
previously assumed, an actual typed tool set:

```typescript
// memory_add — write a new memory item
{
  name: 'memory_add',
  required: ['projectId', 'kind', 'type'],
  properties: {
    projectId: string,
    kind: 'observation' | 'summary' | 'prompt' | 'manual',
    type: string,
    title?: string,
    narrative?: string,
    facts?: string[],
  }
}

// memory_search — semantic search within project/team scope
{
  name: 'memory_search',
  required: ['projectId', 'query'],
  properties: { projectId: string, query: string, limit?: number /* 1-100 */ }
}

// memory_context — compact context pack from matching memories
{
  name: 'memory_context',
  required: ['projectId', 'query'],
  properties: { projectId: string, query: string, limit?: number /* 1-50 */ }
}

// memory_forget — tombstone (not hard-delete) a memory item
{
  name: 'memory_forget',
  required: ['projectId', 'memoryId'],
  properties: { projectId: string, memoryId: string, reason?: string }
}

// memory_list_recent
{
  name: 'memory_list_recent',
  required: ['projectId'],
  properties: { projectId: string, limit?: number /* 1-100 */ }
}

// memory_record_decision — ADR-style, dedicated tool (not a generic memory_add)
{
  name: 'memory_record_decision',
  required: ['projectId', 'title', 'decision'],
  properties: { projectId: string, title: string, decision: string, rationale?: string, consequences?: string[] }
}
```

## When To Use Which Tool

| Need | Tool |
|---|---|
| Record a generic observation/note | `memory_add` |
| Find something from a past session | `memory_search` |
| Get a compact briefing before starting work | `memory_context` |
| Remove an outdated/wrong memory | `memory_forget` (tombstones, doesn't hard-delete) |
| Quick recent history check | `memory_list_recent` |
| **Record WHY an architectural choice was made** | `memory_record_decision` — use this, not `memory_add`, for anything ADR-like |

## REST API (when not using MCP directly)

```
POST /v1/sessions/start   POST /v1/sessions/:id/end
POST /v1/events           POST /v1/events/batch
POST /v1/memories         POST /v1/search          POST /v1/context
GET  /v1/audit?projectId=<id>
```

**Event generation is async by default** — `POST /v1/events` with
`generate=false` writes the event without enqueueing analysis;
`wait=true` returns a `generationJob` descriptor to poll. The actual
LLM analysis runs in a separate worker process (`claude-mem server
worker start`) — the HTTP path never blocks on a provider response.
**This async pattern should inform how NexSidi's own instinct observer
is wired** — observation capture (fast, synchronous) is separate from
pattern analysis (slow, queued, batch-processed).

## Auth

```
CLAUDE_MEM_AUTH_MODE=api-key
Authorization: Bearer <key>
```
Read endpoints require `memories:read` scope, write endpoints require
`memories:write` scope — apply the same read/write scope split to
NexSidi's own internal memory access if a similar service boundary is
ever introduced (e.g. Red/Blue team agents need read-only access to
mistake memory, not write).

## Installation Requirement

Node.js ≥20. Version: confirmed v13.x line from package metadata.

## What This Skill Forbids

1. Using `memory_add` for architectural decisions — use
   `memory_record_decision`, which captures rationale/consequences fields
   `memory_add` doesn't have
2. Hard-deleting via anything other than `memory_forget` (tombstone, not destroy)
3. Blocking the calling agent waiting on `generate=true` analysis when
   `wait=true` wasn't explicitly requested

---
*Source: claude-mem repo's actual src/server/mcp/tools.ts and docs/api.md
read directly — replaces the prior vague "3-layer search" description
with the real 6-tool interface.*
