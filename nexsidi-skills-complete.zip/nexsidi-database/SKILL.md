---
name: nexsidi-database
description: Use when Pranav is creating or altering database tables, adding columns or indexes, running data migrations, or planning any schema change for NexSidi's platform or generated user apps.
allowed-tools:
  - Bash
  - Read
  - Edit
  - Write
---

# NexSidi Database — Migration Discipline
## Source: ECC `database-migrations/SKILL.md` — full patterns, Drizzle focus

## Five Core Principles (from source, verbatim intent)

1. **Every change is a migration** — never alter production databases manually
2. **Migrations are forward-only in production** — rollbacks use new forward migrations
3. **Schema and data migrations are separate** — never mix DDL and DML in one migration
4. **Test migrations against production-sized data** — a migration that works on 100 rows may lock on 10M rows
5. **Migrations are immutable once deployed** — never edit a migration that has run in production

## Safety Checklist — Before Any Migration Runs

- [ ] No full table locks on large tables (use CONCURRENT operations)
- [ ] New NOT NULL columns have defaults (never add NOT NULL without a default)
- [ ] Indexes created with CONCURRENTLY (not inline CREATE TABLE for existing tables)
- [ ] Data backfill is a SEPARATE migration from the schema change
- [ ] Tested against a copy of production data (not just dev's 50-row dataset)
- [ ] Rollback plan documented (even if rollback is "forward migration to undo")

## Drizzle ORM — NexSidi's Primary Tool (Pranav)

```bash
# Generate migration from schema changes
npx drizzle-kit generate

# Apply migrations
npx drizzle-kit migrate

# Push schema directly (DEV ONLY — never on production)
npx drizzle-kit push

# Dry run check
bun run db:migrate:dry-run
```

### Drizzle Schema Conventions

```typescript
import { pgTable, text, timestamp, uuid, boolean, index } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id:        uuid("id").primaryKey().defaultRandom(),
  userId:    text("user_id").notNull(),          // Clerk user ID — always present
  email:     text("email").notNull().unique(),
  isActive:  boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index("idx_users_user_id").on(table.userId),
}));
```

## PostgreSQL Patterns — Safe Operations

### Adding a Column Safely

```sql
-- GOOD: Nullable column, no lock
ALTER TABLE projects ADD COLUMN deploy_url TEXT;

-- GOOD: Boolean with default (Postgres 11+ — instant, no rewrite)
ALTER TABLE projects ADD COLUMN is_archived BOOLEAN NOT NULL DEFAULT false;

-- BAD: NOT NULL without default on existing table — locks table, rewrites ALL rows
ALTER TABLE projects ADD COLUMN status TEXT NOT NULL;
-- Do this instead: add nullable, backfill, then add constraint in separate migration
```

### Adding an Index Without Downtime

```sql
-- BAD: Blocks ALL writes on the table during build
CREATE INDEX idx_projects_user_id ON projects (user_id);

-- GOOD: Non-blocking, concurrent writes still allowed
CREATE INDEX CONCURRENTLY idx_projects_user_id ON projects (user_id);

-- CRITICAL: CONCURRENTLY cannot run inside a transaction block
-- Drizzle needs a custom SQL migration for this — generate empty migration:
npx drizzle-kit generate --name add_projects_user_id_idx
-- Then manually edit the generated SQL to use CONCURRENTLY
```

### Renaming a Column — Expand-Contract Pattern (D8)

**This is the only safe way. Never rename directly in production.**

```sql
-- Migration 001: EXPAND — add new column (nullable)
ALTER TABLE projects ADD COLUMN display_name TEXT;

-- Migration 002: BACKFILL (separate migration, separate deploy)
UPDATE projects SET display_name = name WHERE display_name IS NULL;

-- Application change: read/write BOTH columns (deploy this between 001 and 003)

-- Migration 003: CONTRACT — drop old column (after app is fully reading new column)
ALTER TABLE projects DROP COLUMN name;
```

### Large Data Migrations — Batch Pattern

```sql
-- BAD: Single transaction locks the table
UPDATE projects SET normalized_slug = LOWER(slug);

-- GOOD: Batch with FOR UPDATE SKIP LOCKED
DO $$
DECLARE
  batch_size INT := 5000;
  rows_updated INT;
BEGIN
  LOOP
    UPDATE projects
    SET normalized_slug = LOWER(slug)
    WHERE id IN (
      SELECT id FROM projects
      WHERE normalized_slug IS NULL
      LIMIT batch_size
      FOR UPDATE SKIP LOCKED
    );
    GET DIAGNOSTICS rows_updated = ROW_COUNT;
    RAISE NOTICE 'Updated % rows', rows_updated;
    EXIT WHEN rows_updated = 0;
    COMMIT;
  END LOOP;
END $$;
```

## RLS — Always Enabled (D5 + Generated App Rule)

Every user-data table gets RLS immediately after creation:

```sql
-- NexSidi platform (multi-tenant, user_id column)
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "users can only access their own projects"
ON projects
FOR ALL
USING (user_id = auth.uid()::text);

-- Never generate code that disables RLS
-- Never create a user-data table without an RLS policy in the same migration
```

## Anti-Patterns — Never Do These

| Anti-Pattern | Why It Fails | Correct Approach |
|---|---|---|
| Manual SQL on production | No audit trail, unrepeatable | Always migration files |
| Editing a deployed migration | Causes drift between environments | Create a NEW forward migration |
| NOT NULL without default | Full table rewrite + lock | Add nullable → backfill → add constraint |
| Inline index on large table | Blocks writes during build | CREATE INDEX CONCURRENTLY |
| Schema + data in one migration | Hard to rollback, long locks | Two separate migrations |
| Dropping column before removing code | App crashes on missing column | Remove code → deploy → drop column next deploy |
| `drizzle-kit push` on production | Bypasses migration history | Only `migrate`, never `push`, in production |

## Generated User App Migrations (Pranav for user projects)

Generated apps use Supabase PostgreSQL. Same rules apply:
- RLS always enabled, policy always created in same migration
- Drizzle ORM for type safety
- Expand-contract for any rename or drop
- CONCURRENTLY for any index on an existing table
- The Supabase connection string comes from environment, never hardcoded

---
*Source: ECC `skills/database-migrations/SKILL.md`, read in full — all
patterns (PostgreSQL, Drizzle, batch migrations, zero-downtime strategy)
extracted and applied. NexSidi D5 (multi-tenancy), D7 (no raw SQL),
D8 (expand-contract) applied from CLAUDE.md.*
