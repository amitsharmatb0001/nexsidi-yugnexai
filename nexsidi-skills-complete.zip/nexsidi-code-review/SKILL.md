---
name: nexsidi-code-review
description: Use when reviewing pull requests, code changes, conducting architecture reviews, or establishing review standards for any agent's generated code.
allowed-tools:
  - Read
  - Grep
  - Glob
  - Bash
  - WebFetch
---

# Code Review — Full Source Capture
## Real Severity Taxonomy, Real Reference Map, Corrected Language Decision

## What This Version Fixes

V1/v2 invented a CRITICAL/HIGH/MEDIUM/LOW severity scale and used only 2
of 20 language reference files. This version uses the real source
taxonomy verbatim and wires all reference files, including the 2
previously blocked for being Chinese-language — reversed below.

## Real Severity Taxonomy (verbatim, exact wording from source)

🔴 `[blocking]` — Must fix before merge
🟡 `[important]` — Should fix, discuss if disagree
🟢 `[nit]` — Nice to have, not blocking
💡 `[suggestion]` — Alternative approach to consider
📚 `[learning]` — Educational comment, no action needed
🎉 `[praise]` — Good work, keep it up!

"🔴 / 🟡 / 🟢 are the three severity tiers used as the standard across
all guides — 🔴 blocks the merge, 🟡 should be addressed, 🟢 is optional.
The remaining markers (💡/📚/🎉) are non-blocking annotations."

## Corrected Decision: Chinese-Language Reference Files

Previously blocked `typescript.md` and `performance-review-guide.md` for
having Chinese narrative text. **Reversed.** Navya and Karan run on Kimi
K2.6 (Moonshot AI — a Chinese-origin model). Chinese-language reference
content is not a liability for these specific agents; it may be more
natively understood than the English equivalent. All 20 language guides
are now in scope, not just the 2 previously deemed "safe."

## Reference File Map (all 20, full table)

| Language | File | Key Topics |
|---|---|---|
| React | `react.md` | Hooks, useEffect, React 19 Actions, RSC, Suspense, TanStack Query v5 |
| Vue 3 | `vue.md` | Composition API, reactivity, Props/Emits, Watchers, Composables |
| Angular 17+ | `angular.md` | Signals, Standalone components, RxJS, Zoneless change detection |
| Rust | `rust.md` | Ownership/borrowing, unsafe review, async, cancellation safety |
| TypeScript | `typescript.md` | Type safety, async/await, immutability — **NexSidi's primary language** |
| Python | `python.md` | Mutable defaults, exception handling, class attributes |
| Django/DRF | `django.md` | Security, N+1 queries, Serializer anti-patterns, async views |
| FastAPI | `fastapi.md` | Depends, Pydantic v2, async correctness, sessions/N+1, auth |
| Java | `java.md` | Java 17/21, Spring Boot 3, virtual threads, Stream/Optional |
| PHP | `php.md` | PHP 8.x types, PDO, security, Composer, PHPUnit/PHPStan |
| C#/.NET | `csharp.md` | C# 12, async, EF Core performance, ASP.NET Core, LINQ |
| Go | `go.md` | Error handling, goroutine/channel, context, interface design |
| Kotlin/Android | `kotlin.md` | Coroutines, Flow, Jetpack Compose, null safety, leaks |
| Swift/SwiftUI | `swift.md` | Optionals, Swift Concurrency, Sendable/actors, property wrappers |
| NestJS | `nestjs.md` | DI, layered architecture, DTO validation, Guard/Interceptor |
| Svelte/SvelteKit | `svelte.md` | Runes, Load functions, Form Actions, SSR/CSR boundary |
| C | `c.md` | Pointers/buffers, memory safety, UB, error handling |
| C++ | `cpp.md` | RAII, lifetimes, Rule of 0/3/5, exception safety |
| CSS/Less/Sass | `css-less-sass.md` | Variables, !important, performance, responsive |
| Qt | `qt.md` | Object model, signals/slots, memory management, threading |

**Cross-cutting (language-agnostic):** `code-quality-universal.md` —
reuse audit, parameter sprawl, leaky abstractions, nested conditionals,
stringly-typed code, TOCTOU, no-op updates, redundant state.

**Additional guides:** `architecture-review-guide.md` (SOLID, coupling,
anti-patterns), `performance-review-guide.md` (Web Vitals, N+1,
complexity), `common-bugs-checklist.md`, `security-review-guide.md`,
`code-review-best-practices.md`. **Templates:** `assets/pr-review-template.md`,
`assets/review-checklist.md`.

## The 4-Phase Process (exact timing budgets — real, not estimated)

| Phase | Time | What |
|---|---|---|
| 1. Context Gathering | 2-3 min | Read PR description, check size (>400 lines? ask to split), check CI status |
| 2. High-Level Review | 5-10 min | Architecture fit, performance assessment, file org, testing strategy |
| 3. Line-by-Line | 10-20 min | Logic, security, performance, maintainability, **reuse check** |
| 4. Summary & Decision | 2-3 min | Approve / Comment / Request Changes |

**For large diffs:** pipe through `scripts/pr-analyzer.py`
(`git diff main...HEAD | python scripts/pr-analyzer.py`) to triage
complexity and get a suggested review approach BEFORE reading line by line.

## The Reuse Check (Phase 3 — previously missing entirely)

"Before accepting new code, search for existing utilities/helpers that
could replace it. Check adjacent files and shared modules for similar
patterns." — a real DRY-enforcement step, not just style review. Wire
this into Navya's logic-review pass explicitly.

## Effective Feedback Patterns (verbatim)

```
❌ "This is wrong."
✅ "This could cause a race condition when multiple users access
    simultaneously. Consider using a mutex here."

❌ "This will fail if the list is empty."          [statement]
✅ "What happens if `items` is an empty array?"     [question approach]

❌ "You must change this to use async/await"
✅ "Suggestion: async/await might make this more readable. What do you think?"
```

## What to Review vs What Not To (verbatim)

**Review:** logic correctness, security, performance, test coverage,
error handling, docs/comments, API design, architectural fit.

**Do NOT manually review:** code formatting (use Prettier/Biome), import
organization, linting violations, simple typos — these are a linter's
job, not a reviewer's.

## What This Skill Forbids

1. Inventing a severity scale instead of using the real 🔴/🟡/🟢 + 💡/📚/🎉 system
2. Blocking Chinese-language reference content for Kimi-based agents
   (Navya, Karan) — they read it natively
3. Skipping the Reuse check during line-by-line review
4. Manually flagging formatting/import-order issues — that's the linter's job
5. Skipping `pr-analyzer.py` triage on diffs over 400 lines

---
*Source: awesome-skills/code-review-skill — full repo read, all 20
language files + 5 cross-cutting guides + 2 scripts + 2 asset templates
catalogued, core SKILL.md read in complete depth.*
