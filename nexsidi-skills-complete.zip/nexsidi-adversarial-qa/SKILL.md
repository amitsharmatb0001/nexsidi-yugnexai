---
name: nexsidi-adversarial-qa
description: Use after development agents complete code generation and before any preview or delivery is shown to a user.
---

# Adversarial QA — Generator-Evaluator Harness
## Patent Claim 4

## Two Distinct Scoring Systems — Use the Right One

V3 used a single CRITICAL/HIGH/MEDIUM/LOW penalty scale for everything.
**This was wrong for half the job.** Per ECC's gan-style-harness (real
source, read in full) there are two genuinely different evaluation types:

**Objective bugs (logic, security, performance)** — these are pass/fail
per-finding, not a holistic aesthetic judgment. Severity-penalty scoring
is correct here:
```typescript
const SEVERITY_PENALTY = { CRITICAL: 20, HIGH: 10, MEDIUM: 5, LOW: 1 };
const STATIC_PASS_THRESHOLD = 85; // out of 100
```

**Subjective/holistic quality (design, originality, craft, functionality
of the live app)** — weighted 1-10 scale. The EXACT criteria language
belongs in BOTH generator and evaluator prompts — this is how you
calibrate the loop (Source: Anthropic Mar 2026 harness blog, verbatim):

```typescript
const LIVE_EVAL_CRITERIA = {
  designQuality: {
    weight: 0.35,
    verbatim: "Does the design feel like a coherent whole rather than a " +
      "collection of parts? Strong work means colors, typography, layout, " +
      "imagery, and other details combine to create a distinct mood and identity."
  },
  originality: {
    weight: 0.35,
    verbatim: "Is there evidence of custom decisions, or is this template " +
      "layouts, library defaults, and AI-generated patterns? A human designer " +
      "should recognize deliberate creative choices. Unmodified stock components" +
      "—or telltale signs of AI generation like purple gradients over white " +
      "cards—fail here."
  },
  craft: {
    weight: 0.15,
    verbatim: "Technical execution: typography hierarchy, spacing consistency, " +
      "color harmony, contrast ratios. A competence check rather than a " +
      "creativity check. Most reasonable implementations do fine here by " +
      "default; failing means broken fundamentals."
  },
  functionality: {
    weight: 0.15,
    verbatim: "Usability independent of aesthetics. Can users understand " +
      "what the interface does, find primary actions, and complete tasks " +
      "without guessing?"
  },
};
const LIVE_PASS_THRESHOLD = 7.0;

// WHY these weights: Claude already scores well on Craft and Functionality
// by default. Design quality and Originality are where it produces "AI slop"
// — safe, predictable, visually unremarkable. Weighting them 0.35 each
// pushes the generator toward aesthetic risk-taking and away from
// purple-gradients-over-white-cards. Source: Anthropic Mar 2026 blog —
// "I emphasized design quality and originality over craft and functionality."

function calculateLiveScore(scores: Record<keyof typeof LIVE_EVAL_CRITERIA, number>): number {
  return Object.entries(LIVE_EVAL_CRITERIA).reduce(
    (sum, [key, { weight }]) => sum + scores[key as keyof typeof scores] * weight, 0
  );
}
```

## The Three Agents (Planner-Generator-Evaluator, confirmed exact)

| Agent | NexSidi mapping | Real model tier per ECC |
|---|---|---|
| Planner | Arjun (spec expansion) | Opus-tier — deep reasoning for spec expansion |
| Generator | Shubham/Aanya/Pranav | Opus-tier — strong coding capability |
| Evaluator | Navya/Karan/Deepika | Opus-tier — strong judgment + tool use |

**Planner is deliberately ambitious** — "conservative planning leads to
underwhelming results." Arjun should expand a 1-4 sentence brief into a
full ambitious spec, not a minimal-viable one.

## Live Evaluation Modes (three, not always Playwright)

```typescript
type EvalMode = "playwright" | "screenshot" | "code-only";

const EVAL_MODE_BY_PROJECT_TYPE: Record<string, EvalMode> = {
  "full-stack-with-ui": "playwright",   // interact with live app
  "static-design-only": "screenshot",    // visual-only, no interaction needed
  "api-or-cli-only": "code-only",        // tests + lint + build, no UI to evaluate
};
```
Previously NexSidi assumed Playwright always — this is wrong for
API-only or CLI-only generated projects, where code-only evaluation
(tests, lint, build success) is the correct and cheaper mode.

## Stuck Detection — Exact ECC Wording, Confirms Existing Logic

> "If the generator can't improve past a score plateau after 3
> iterations, stop and flag for human review."

This matches what was already built (3-iteration window, no
arbitrary cap otherwise) — independently confirmed a fourth time now
across NEXUS, Multi-Agent Systems Architect, the Anthropic blog post,
and this ECC skill. Keep 3.

## Cost Reality (exact range, now from a third independent source)

| Metric | Solo agent | Full harness |
|---|---|---|
| Time | 20 min | 4-6 hours (12-18x) |
| Cost | $9 | $125-200 (14-22x) |

For NexSidi's Phase 1 demo: static review every iteration, live
evaluation only on the iteration about to PASS — keeps demo speed while
guaranteeing the final delivered app was live-tested.

## Evaluator Calibration — Required Before First Run

Out of the box, the evaluator is a poor QA agent. Early runs show it
identifying real issues then talking itself out of flagging them. Fix:

1. **Tune for skepticism explicitly** — the evaluator prompt must say
   "be skeptical of LLM-generated outputs, assume issues exist until
   evidence proves otherwise" — not "evaluate fairly"
2. **Few-shot examples with detailed score breakdowns** — give the
   evaluator 2-3 example outputs with scores and the exact reasoning
   behind each score. This reduces score drift across iterations.
3. **Tuning loop** — read evaluator logs, find where its judgment
   diverges from expected, update the prompt. Expect several rounds
   before it grades at an acceptable standard.
4. **Depth of testing** — evaluator must INTERACT (Playwright), not
   scan. Superficial testing misses bugs in deeply nested features.

## The Evaluator Is Not a Fixed Yes/No Decision

"The evaluator is worth the cost when the task sits beyond what the
current model does reliably solo." — Anthropic Mar 2026

As Opus 4.6 improves, tasks that previously needed the evaluator fall
within what the generator handles well alone. The evaluator overhead
becomes unnecessary for those tasks. Do NOT run the full evaluator loop
on every task regardless of complexity. Apply it where the generator
is genuinely at the edge of its capability; skip it (or reduce to a
single-pass) for tasks within the model's reliable solo range.

## Anti-Patterns (verbatim from ECC, all directly applicable)

1. **Evaluator too lenient** — if it passes everything on iteration 1,
   the rubric is too generous; tighten and add explicit AI-pattern penalties
2. **Generator ignoring feedback** — feedback MUST be passed as a file
   the generator reads at start of next iteration, never inline-only
3. **Infinite loops** — `GAN_MAX_ITERATIONS` style hard cap always set
   even with stuck-detection as primary exit
4. **Evaluator testing superficially** — must INTERACT via Playwright,
   never just screenshot
5. **Evaluator praising its own fixes** — evaluator only critiques,
   generator fixes, never the reverse
6. **Context exhaustion** — use automatic compaction or reset between
   major phases for long sessions

## Configuration (env-var pattern, adopt for NexSidi's pipeline config)

```bash
NEXSIDI_QA_MAX_ITERATIONS=15
NEXSIDI_QA_STUCK_WINDOW=3
NEXSIDI_QA_LIVE_PASS_THRESHOLD=7.0
NEXSIDI_QA_STATIC_PASS_THRESHOLD=85
NEXSIDI_QA_EVAL_MODE=playwright   # playwright | screenshot | code-only
NEXSIDI_QA_DEV_SERVER_PORT=3000
```

## What This Skill Forbids

1. Using severity-penalty scoring for subjective design/craft judgment
   — use the weighted 1-10 rubric instead
2. Using weighted 1-10 scoring for objective bugs — use severity-penalty
3. Always defaulting to Playwright mode regardless of project type
4. Evaluator and Generator sharing the same context/conversation history
5. Skipping the live evaluation pass to save cost on the FINAL
   pre-delivery iteration specifically

---
*Source: ECC gan-style-harness (full SKILL.md read, not excerpted) +
Anthropic's harness-design-long-running-apps (full blog read). Fixes
the single-scoring-system error from v3.*
