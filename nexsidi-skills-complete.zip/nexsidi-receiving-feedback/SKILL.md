---
name: nexsidi-receiving-feedback
description: Use when receiving adversarial QA findings from Navya/Karan/Deepika, code review from the review gate, or any external feedback — before implementing any suggestion.
allowed-tools:
  - Read
  - Bash
  - Grep
---

# NexSidi Receiving Feedback — Evaluate Before Implementing
## Source: Superpowers `receiving-code-review` + NexSidi D40

## Why This Exists (D40)

Agents that blindly implement every adversarial finding without
verification defeat the purpose of adversarial QA. An evaluator
finding that's incorrect — misread code, wrong context, stale
assumption — still gets implemented because no agent was told to
push back. This skill is the fix.

## The Response Pattern

```
WHEN receiving adversarial findings or review feedback:

1. READ: Complete findings list without reacting
2. UNDERSTAND: Restate each finding in your own words, or ask
3. VERIFY: Check the finding against the actual codebase
4. EVALUATE: Is it technically correct for THIS code, THIS stack?
5. RESPOND: Technical acknowledgment, or reasoned pushback
6. IMPLEMENT: One finding at a time, test each, then the next
```

## Forbidden Responses

**NEVER:**
- "You're absolutely right!" (before verification)
- "Great catch!" (performative, proves nothing)
- "Let me implement all of that now" (before checking any of it)
- Implement multiple findings at once

**INSTEAD:**
- Restate the technical issue
- Verify against the code
- Push back with technical reasoning when wrong
- Fix one item, verify it works, then move to the next

## Handling Unclear Findings

If ANY finding is unclear: STOP. Do not implement anything yet. Ask
for clarification on the unclear items. Items may be related — partial
understanding = wrong implementation.

```
Navya flags items 1-6.
You understand 1, 2, 3, 6. Items 4 and 5 are unclear.

WRONG: Implement 1,2,3,6 now, ask about 4,5 later
RIGHT: "I understand items 1,2,3,6. Need clarification on 4 and 5
       before implementing any of them."
```

## When to Push Back on Adversarial Findings

Push back when:
- The finding describes code that doesn't exist at the referenced line
- The "vulnerability" requires attack conditions that the sandbox
  (Patent Claim 5) structurally prevents
- The performance issue is below the P95 < 200ms threshold (D46)
  and not actually failing
- The finding conflicts with a locked architectural decision (D1-D50)
- Two findings contradict each other

**How to push back:**
```typescript
// Navya flags: "null dereference at line 47"
// Verify: grep the actual file
// Discovery: line 47 has a null guard — the finding is stale
// Response: "Checked line 47 — null guard at line 45 prevents this.
//           The finding appears to reference a previous version.
//           Showing current code: [paste relevant lines]"
```

## YAGNI Check for "Professional Feature" Suggestions

If an evaluator suggests adding something not in the locked spec:
```bash
# First: check if the suggested feature is actually used anywhere
grep -r "featureName" src/ --include="*.ts"
```

If unused: "This isn't in the locked spec (Saanvi's ProjectSpec JSON,
field X). YAGNI — defer to spec revision process if it's needed."

## Implementation Order for Multi-Finding Feedback

1. Clarify anything unclear FIRST — all items, before implementing any
2. Then implement in this priority:
   - CRITICAL / blocking (🔴 — must fix, breaks QA gate)
   - HIGH / important (🟡 — should fix, discuss if disagree)
   - MEDIUM / nit (🟢 — optional, can defer)
3. Test each fix individually before moving to the next
4. Verify no regressions after each fix

## After Implementing Correctly

No performative language:
```
✅ "Fixed. Line 47 now validates input before the database call."
✅ "Corrected. The race condition in the Temporal workflow was in the
    retry handler, not the initial dispatch. Changed the handler."
✅ [Just fix it and show the relevant code change]

❌ "Great catch!"
❌ "You were absolutely right!"
❌ "Thanks for the thorough review!"
```

Actions speak. The code change is the acknowledgment.

---
*Source: Superpowers `skills/receiving-code-review/SKILL.md`, read in
full. NexSidi D40 (critical gap) applied — adversarial QA evaluation
discipline added per CLAUDE.md Part 2.*
