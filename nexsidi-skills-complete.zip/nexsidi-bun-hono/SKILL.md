---
name: nexsidi-bun-hono
description: Use when writing, reviewing, or generating any code for NexSidi's own API layer — Shubham's TypeScript + Bun + Hono backend.
allowed-tools:
  - Read
  - Bash
  - Edit
  - Write
---

# NexSidi API Layer — TypeScript + Bun + Hono
## Source: CLAUDE.md Part 2 (D1, D7, D8, D33, D34)

## Stack Decision (D1 — decided, do not relitigate)

NexSidi's own API uses **TypeScript + Bun + Hono**. Prior decision was
Rust + Axum — changed because the entire stack is TypeScript and Rust
expertise isn't justified for the API layer. Rust stays ONLY in the
sandbox layer (Patent Claim 5). If a proposal adds Rust to the API
layer, reject it.

## Project Structure

```
src/
├── index.ts              # Bun entry point, port 8080
├── app.ts                # Hono app, middleware registration
├── routes/
│   ├── auth.ts           # Clerk webhook + session validation
│   ├── projects.ts       # Project CRUD
│   ├── pipeline.ts       # Agent pipeline trigger endpoints
│   └── admin.ts          # Internal-only, separate auth tier
├── middleware/
│   ├── auth.ts           # JWT RS256 validation (Clerk)
│   ├── rateLimit.ts      # Per-user rate limiting
│   └── security.ts       # Input sanitization, injection detection
├── db/
│   └── client.ts         # Drizzle ORM client (Pranav's domain)
└── agents/
    └── client.ts         # LLM client (nexsidi-llm-client)
```

## Hono Patterns

```typescript
import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { logger } from 'hono/logger'

const app = new Hono()

// Middleware
app.use('*', cors({ origin: process.env.FRONTEND_URL }))
app.use('*', logger())

// Route with auth
app.post('/projects', authMiddleware, async (c) => {
  const body = await c.req.json()
  // validate with Zod before touching DB
  const parsed = ProjectCreateSchema.safeParse(body)
  if (!parsed.success) {
    return c.json({ error: parsed.error.format() }, 400)
  }
  // ... handler
})

export default app
```

## Bun Dev/Run Commands

```bash
bun run dev      # localhost:8080 with hot reload
bun run build    # compile to ./dist/
bun test         # run all *.test.ts
bun run typecheck # tsc --noEmit
```

## Critical Rules

**D7 — No raw SQL through the agent harness.** Agents call typed,
read-only functions (`getProjectSchema`, `getUserProjects`) — never
arbitrary SQL strings. Pranav owns the DB layer; Shubham calls typed
functions from it.

**D8 — Expand-contract migrations only.** When a DB change is needed:
expand (add new column/table) → backfill → verify → contract (remove
old). Never rename or drop in one migration on production.

**D33/D34 — `approvedBy` is never an agent name.** The permission
harness requires every approval record to carry either
`"policy:rule-name"` or a real human account ID. Shubham's API
endpoints that trigger approval flows must enforce this.

## Input Sanitization (Layer 1 Security)

Every user message, file upload, and URL goes through classification
BEFORE reaching any route handler:
- Instruction injection patterns
- Authority claims
- Encoding tricks (base64, ROT13, reversed text)
- Role-play escalation

Route handlers receive pre-sanitized content wrapped in XML trust
markers. No route handler should trust raw request body content as
instruction-level input to an agent.

## Auth — Clerk JWT RS256

```typescript
// Middleware: validate Clerk session token
import { clerkMiddleware } from '@hono/clerk-auth'

app.use('*', clerkMiddleware())

// In route: get verified user
const auth = getAuth(c)
if (!auth?.userId) return c.json({ error: 'Unauthorized' }, 401)
```

## WebSocket (Real-Time Status to Frontend)

WebSocket events are translated through a deny-by-default translator
before reaching the user. Every internal event type not explicitly
whitelisted returns null and is never sent to the client.

```typescript
const ALLOWED_WS_EVENTS = new Set([
  'stage:setting-up',
  'stage:designing',
  'stage:building',
  'stage:quality-check',
  'stage:deploying',
  'stage:complete',
  'stage:error', // generic — no internal details
]);

function translateEvent(internal: InternalEvent): UserEvent | null {
  if (!ALLOWED_WS_EVENTS.has(internal.type)) return null;
  return { type: internal.type, message: USER_MESSAGES[internal.type] };
}
```

---
*Source: CLAUDE.md Part 1 (tech stack section), Part 2 (D1, D7, D8,
D33, D34), security model Layer 1 and 7.*
