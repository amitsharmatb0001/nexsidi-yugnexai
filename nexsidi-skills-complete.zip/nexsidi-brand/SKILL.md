---
name: nexsidi-brand
description: Use when creating branded content, checking tone of voice, generating marketing assets, or needing brand consistency across any YugNex or NexSidi-facing material.
allowed-tools:
  - Bash
  - Read
  - Glob
---

# NexSidi Brand — Identity, Voice, Tokens, Assets
## Source: ui-ux-pro-max `.claude/skills/brand/SKILL.md`

## Core Files — Source of Truth Hierarchy

```
docs/brand-guidelines.md      ← Primary source of truth (edit here)
assets/design-tokens.json     ← Token definitions (synced from above)
assets/design-tokens.css      ← CSS variables (generated from tokens)
```

Never hardcode colors, fonts, or spacing in CSS. Use tokens.
`var(--color-primary)`, `var(--typography-font-heading)`, etc.

## Quick Commands

```bash
# Inject brand context into any prompt (required before branded content)
node scripts/inject-brand-context.cjs

# JSON output (for programmatic use)
node scripts/inject-brand-context.cjs --json

# After editing brand-guidelines.md, sync to all token files
node scripts/sync-brand-to-tokens.cjs

# Validate an asset before using it
node scripts/validate-asset.cjs <asset-path>

# Extract or compare colors against the approved palette
node scripts/extract-colors.cjs --palette
node scripts/extract-colors.cjs <image-path>
```

## Brand Sync Workflow (when brand changes)

```
1. Edit docs/brand-guidelines.md
2. Run: node scripts/sync-brand-to-tokens.cjs
3. Verify: node scripts/inject-brand-context.cjs --json | head -20
4. Commit: git add docs/brand-guidelines.md assets/design-tokens.*
```

## YugNex Brand Constraints (from established identity)

**Visual identity:** Black/gold aesthetic. Sanskrit-to-English morphing
as a core brand motion. Premium, technical, Indian-origin but global
positioning.

**Voice:** Direct, confident, technically precise. No "we might,"
"could potentially," or hedging. NexSidi builds — it doesn't suggest.

**Confidentiality rule applies to brand content too:** No agent names
("Tilotma," "Shubham," etc.), no agent count, no internal architecture
in ANY user-facing or external material — including marketing copy,
website, social posts, pitch decks, or press materials.

**External description ceiling:** "A coordinated multi-agent system"
or "our proprietary AI pipeline" — never more specific than what the
10 patent claims already disclose.

## Asset Naming Convention

```
kebab-case: {component}-{variant}-{size}.{ext}
Examples:
  logo-primary-1x.svg
  logo-mark-dark-2x.png
  banner-linkedin-1584x396.png
  icon-app-512x512.png
```

Date prefix for time-sensitive: `{YYMMDD}-{component}-{size}.{ext}`

## References (for deeper brand work)

| Topic | File |
|---|---|
| Voice + tone framework | `references/voice-framework.md` |
| Visual identity standards | `references/visual-identity.md` |
| Messaging frameworks | `references/messaging-framework.md` |
| Brand consistency checklist | `references/consistency-checklist.md` |
| Color palette management | `references/color-palette-management.md` |
| Logo usage rules | `references/logo-usage-rules.md` |
| Asset approval checklist | `references/approval-checklist.md` |

---
*Source: ui-ux-pro-max `.claude/skills/brand/SKILL.md` and
`references/brand-guideline-template.md`,
`references/color-palette-management.md`, read in full. YugNex brand
identity applied from memory.*
