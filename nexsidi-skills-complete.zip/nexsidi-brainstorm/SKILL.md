---
name: nexsidi-brainstorm
description: Use before any creative or implementation work — creating features, building components, adding functionality, or modifying behavior. Must run before nexsidi-planning.
allowed-tools:
  - Read
  - Bash
  - Glob
---

# NexSidi Brainstorm — Design Before Code
## Source: Superpowers `brainstorming`

## Hard Gate

```
DO NOT write code, scaffold, or take any implementation action
until you have presented a design and it has been approved.
```

This applies to every request, regardless of perceived simplicity.
A "simple" feature with unexamined assumptions causes more wasted
work than a complex one that was designed first. The design can be
short — a few sentences for truly simple things — but it MUST be
presented and approved.

## Checklist — Complete in Order

1. **Explore project context** — read PROGRESS.md, recent git commits,
   relevant files. Never brainstorm blind.

2. **Scope check** — does this cover multiple independent subsystems?
   (e.g. "add monitoring, auth, and billing") If yes, decompose into
   sub-projects first. Each sub-project gets its own brainstorm → plan
   → build cycle.

3. **Ask clarifying questions** — ONE per message. Multiple choice
   preferred over open-ended. Focus on: purpose, constraints, success
   criteria. Stop when you understand what you're building.

4. **Propose 2-3 approaches** with trade-offs. Lead with your
   recommendation and explain why.

5. **Present design** — scaled to complexity. Ask after each section
   whether it looks right. Cover: architecture, components, data flow,
   error handling, testing approach.

6. **Write design doc** to `docs/nexsidi/specs/YYYY-MM-DD-<topic>-design.md`
   and commit it.

7. **Spec self-review (inline, no subagent):**
   - Placeholder scan: any "TBD", "TODO", vague requirements? Fix them.
   - Consistency: do any sections contradict each other?
   - Scope: is this one implementation plan, or does it need decomposition?
   - Ambiguity: any requirement interpretable two ways? Pick one explicitly.

8. **User reviews written spec** — ask them to review before proceeding.
   Wait for response. Make changes if requested.

9. **Transition to nexsidi-planning** — invoke it to create the
   implementation plan. This is the ONLY next step from brainstorm.
   Never jump to any other skill.

## Design Principles

**Isolation and clarity:** Break the system into units each with one
clear purpose, communicating through well-defined interfaces, testable
independently. If you can't answer "what does this unit do, how do
you use it, what does it depend on?" — the boundary needs work.

**Working in existing NexSidi code:** Explore the current structure
before proposing changes. Follow existing patterns (TypeScript/Bun/
Hono on API layer, Next.js 14 App Router on frontend, Drizzle ORM on
DB layer). Where existing code has problems that affect the work,
include targeted improvements. Don't propose unrelated refactoring.

**YAGNI ruthlessly:** Remove unnecessary features from all designs.
"We might need X later" is not a design requirement.

## NexSidi-Specific Constraints to Check in Every Design

Before presenting any design, verify it's compatible with:
- Patent Claims 1/3/7 (hash chain on every agent context transfer)
- Patent Claim 4 (adversarial QA gate before any user delivery)
- Patent Claim 5 (sandbox isolation for generated code execution)
- Confidentiality rule (no agent names/counts in any user-facing surface)
- Stack decisions D1/D2 (NexSidi uses Bun+Hono; generated apps use Express)
- Multi-tenancy model D5 (same DB, user_id columns — not separate schemas)

---
*Source: Superpowers `skills/brainstorming/SKILL.md`, read in full.
NexSidi constraints applied from CLAUDE.md and architectural decisions.*
