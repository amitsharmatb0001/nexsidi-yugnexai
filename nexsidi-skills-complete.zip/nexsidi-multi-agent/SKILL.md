---
name: nexsidi-multi-agent
description: Use when orchestrating multiple NexSidi agents across a project build, managing agent state and ownership, preventing parallel write conflicts, or diagnosing why a multi-agent pipeline is producing output but not mergeable product.
allowed-tools:
  - Read
  - Bash
  - Write
---

# NexSidi Multi-Agent Orchestration — Team-Based Coordination
## Source: ECC `team-agent-orchestration/SKILL.md`

## Operating Model

Treat every agent as a teammate with a narrow contract — not a
general assistant that can do anything. Five things define each agent:

- **Owner**: the agent (and ultimately Tilotma) accountable for the card
- **Scope**: exact files, branch, worktree, and forbidden areas
- **State**: backlog → ready → running → review → blocked → merged → archived
- **Evidence**: tests, screenshots, logs, review notes — not just code
- **Merge gate**: the exact condition that allows integration into main

No agent starts work without all five fields defined. No agent completes
without evidence and a passed merge gate. That's the full contract.

## Agent Kanban — NexSidi Card Format

```json
{
  "id": "agent-card-{projectId}-{role}",
  "title": "{specific deliverable}",
  "owner": "shubham | aanya | pranav | aarav | riya | ...",
  "state": "ready",
  "branch": "feat/{projectId}-backend",
  "worktree": "/workspace/{projectId}-shubham",
  "acceptance": [
    "All endpoints in API contract respond with correct shapes",
    "bun test passes: 0 failures",
    "bun run build exits 0"
  ],
  "merge_gate": "nexsidi-adversarial-qa static score ≥ 85 AND live eval ≥ 7.0",
  "handoff": "docs/{projectId}/handoffs/shubham-{timestamp}.md"
}
```

## Kanban Column Definitions

| State | Meaning | Exit Criteria |
|---|---|---|
| Backlog | Candidate work, not yet shaped | Acceptance criteria written |
| Ready | Shaped and assignable | Owner + branch/worktree assigned |
| Running | Agent actively working | Handoff artifact + changed files exist |
| Review | Work complete but not merged | Tests + diff review + QA gate pass |
| Blocked | Needs external input or failed gate | Blocker has owner and next action |
| Merged | Integrated into mainline | PR merged or local main updated |
| Archived | No longer relevant | Reason recorded |

A card with no acceptance criteria is board theater — it looks like
work but can't be verified. Reject it at the Ready stage.

## Team-Based Orchestration Flow (Tilotma as conductor)

1. **Shape the board.** Convert Saanvi's locked ProjectSpec into work
   items with owners and merge gates. Use `nexsidi-preflight` Gate 3
   (team contracts) to lock acceptance criteria before any agent starts.

2. **Pick execution mode.**
   - Parallel (Shubham + Aanya + Pranav simultaneously) → requires
     `nexsidi-preflight` Gate 4 (independence check) to pass first
   - Sequential → use when tasks depend on each other's output

3. **Assign boundaries.** One owner per card. Clear file scope.
   No overlapping writes without an integrator step explicitly planned.
   Use `nexsidi-git-workflow` to set up worktrees before dispatching.

4. **Run agents.** Each agent writes evidence AND handoff notes — not
   just code. No card moves from Running to Review without a handoff
   artifact at `handoff` path.

5. **Review in sequence.** Tests first (nexsidi-testing verification),
   then diff review (nexsidi-code-review), then adversarial QA gate
   (nexsidi-adversarial-qa), then product/spec compliance
   (nexsidi-agency-engineers Aarav gate).

6. **Merge deliberately.** One integrator (Arjun) resolves conflicts
   and updates the control pane. Never two agents merging simultaneously.

7. **Extract reusable skill.** If the same card pattern appears in a
   second project, promote it to a shared skill file.

## Failure Modes — What Tilotma Watches For

| Failure | Signal | Fix |
|---|---|---|
| Agent soup | Many agents running, no owner or merge gate defined | Stop everything. Shape the board first. |
| Invisible work | Useful output exists only in a chat transcript | Require handoff artifacts — file evidence, not memory |
| Board theater | Kanban exists but cards have no acceptance criteria | Block the card at Ready until criteria are written |
| Overlapping writes | Parallel agents edited the same file | Independence check (Gate 4) failed — should have caught this |
| No product artifact | Process produces docs but no runnable surface | Merge gate must require a deployed or runnable output |

## Control Pane — What Tilotma's View Must Show

- Active work items and their Kanban state
- Owner, branch, worktree, last heartbeat
- Links to handoff artifacts, tests, screenshots, PR
- Blockers grouped by owner with unblock action
- Merge readiness by gate, not by optimism
- Cards that have become reusable skill candidates

## NexSidi Priority Escalation From Team Ops

Any blocker that cannot be resolved by the owning agent within one
session goes to Tilotma. Tilotma either resolves or pages Amit with
one specific question and concrete options — never "something went
wrong" or "there were bugs."

---
*Source: ECC `skills/team-agent-orchestration/SKILL.md`, read in full.
NexSidi agent roster, worktree paths, QA gates, and escalation model
applied from CLAUDE.md.*
