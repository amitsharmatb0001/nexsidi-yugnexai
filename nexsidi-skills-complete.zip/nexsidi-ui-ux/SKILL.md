---
name: nexsidi-ui-ux
description: Use when building any UI for NexSidi's own platform or for generated user apps — design system generation, style/color/typography decisions, UX guidelines, chart selection, and stack-specific component patterns.
allowed-tools:
  - Bash
  - Read
  - Glob
---

# NexSidi UI/UX — Design Intelligence from Real Databases
## Source: ui-ux-pro-max-skill (CLAUDE.md + templates + scripts)

## How the Tool Works

ui-ux-pro-max ships a real search engine (BM25 + regex, `search.py`)
against real CSV databases. Use the CLI — don't guess styles or invent
color palettes. The databases have 2,000+ design decisions pre-scored.

**Python 3 is the only dependency. No pip installs.**

```bash
# Basic: auto-detect domain from query
python3 skills/ui-ux-pro-max/scripts/search.py "saas dashboard dark mode"

# Domain-specific
python3 skills/ui-ux-pro-max/scripts/search.py "investor pitch" --domain landing
python3 skills/ui-ux-pro-max/scripts/search.py "line chart revenue" --domain chart

# Full design system (always start here for new pages)
python3 skills/ui-ux-pro-max/scripts/search.py "ai coding tool saas" --design-system -p "NexSidi"

# Stack-specific (Aanya uses nextjs, Vanya uses react)
python3 skills/ui-ux-pro-max/scripts/search.py "form validation" --stack nextjs
```

## Available Domains

| Domain | What it returns |
|---|---|
| `product` | Product type recommendations (SaaS, developer tool, platform) |
| `style` | UI styles + AI prompts + CSS keywords |
| `typography` | Font pairings with Google Fonts imports |
| `color` | Color palettes by product type |
| `landing` | Page structure + CTA strategies |
| `chart` | Chart types + library recommendations |
| `ux` | Best practices + anti-patterns |

## Available Stacks (for `--stack`)

`nextjs` (Aanya's primary), `react`, `html-tailwind`, `shadcn`,
`vue`, `nuxtjs`, `svelte`, `astro`, `react-native`

## Standard Workflow for Any New UI Task

**Step 1: Design system first (required, not optional)**
```bash
python3 skills/ui-ux-pro-max/scripts/search.py \
  "<product-type> <key-descriptors>" --design-system -p "<project-name>"
```
Returns: complete design system — pattern, style, colors, typography,
effects, anti-patterns to avoid.

**Step 2: Persist for the session**
```bash
python3 skills/ui-ux-pro-max/scripts/search.py \
  "<same query>" --design-system --persist -p "<project-name>"
```
Creates `design-system/MASTER.md`. All agents in this project session
read that file instead of re-querying.

**Step 3: Per-component domain queries as needed**
```bash
python3 skills/ui-ux-pro-max/scripts/search.py "data table sorting" --domain ux
python3 skills/ui-ux-pro-max/scripts/search.py "error state empty state" --domain ux
```

## NexSidi Platform vs. Generated App Design — Different Targets

**NexSidi's own platform (admin/internal):**
- Developer-facing, clarity > visual flair
- Query: "developer tool dark mode technical saas"
- Stack: `nextjs` + `shadcn`

**Generated user apps (what Aanya/Vanya build for paying users):**
- Consumer-facing, matches the user's spec and Quality Profile
- Query derived from the locked ProjectSpec (Saanvi's output)
- Stack: `nextjs` + `shadcn` + Tailwind (per generated-stack decision D2)

**These are different searches for different audiences.** Don't use
NexSidi's internal design system to style user-delivered apps.

## Design System Generation — What's Produced

The `--design-system` flag queries all domains in parallel and applies
reasoning rules from `ui-reasoning.csv`. Output includes:

```
Pattern: [e.g., "functional-minimal with accent hierarchy"]
Style:   [e.g., "glassmorphism" or "clean-utility"]
Colors:  [primary + secondary + neutral + semantic palette]
Fonts:   [heading + body pairing with Google Fonts import URL]
Effects: [shadows, borders, animation level]
Anti-patterns: [what to avoid for this product type]
```

This output goes into Vanya's design token file, not into CSS directly.
Tokens propagate via CSS variables (var(--color-primary) etc.).

---
*Source: ui-ux-pro-max `CLAUDE.md`, `templates/base/skill-content.md`,
`templates/base/quick-reference.md`, and the full scripts/data
architecture. NexSidi dual-stack distinction applied from CLAUDE.md
Part 1 (D2).*
