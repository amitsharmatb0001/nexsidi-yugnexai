---
name: nexsidi-preflight
description: Use at the start of every new user project build, before any agent writes a single line of code — runs feasibility, spec lock, team contracts, and independence check.
allowed-tools:
  - Read
  - Bash
  - Glob
---

# NexSidi Preflight — Phase 0 Project Gate
## Source: CLAUDE.md architectural decisions D21-D25, D33, D34

## What This Is

Every real development team does a feasibility study and pre-planning
session before building starts. This is NexSidi's equivalent: a
structured gate that runs BEFORE any agent writes any code. It prevents
the four most common pipeline failures: wrong thing built, scope creep
mid-build, parallel agent conflicts, and teams surprised at deployment.

Run this gate on EVERY project. There are no "simple" exceptions.

---

## Gate 1: Feasibility Check

**Can this be built with the current generated-stack (D2)?**

```
Frontend:  Next.js 14 + TypeScript + Tailwind + shadcn/ui
Backend:   Node.js + Express + TypeScript
Database:  PostgreSQL via Supabase (RLS always enabled)
Auth:      Clerk
Deploy:    Vercel (frontend) + Railway (backend) + Supabase (DB)
```

Check each:
- Does the request require real-time (WebSocket)? → Flag: needs extra
  infra beyond standard generated stack
- Does it require native mobile? → Out of scope for Phase 1
- Does it require third-party integrations? → List them; check API
  availability before committing the spec
- Does it require file storage? → Flag: Supabase Storage or external CDN
- Does it require email/SMS? → Flag: Resend or Twilio dependency

If anything is outside the standard stack: **flag to Tilotma BEFORE
Saanvi writes the spec.** Never discover stack gaps after 3 iterations.

---

## Gate 2: Spec Lock (Saanvi)

Saanvi writes the ProjectSpec JSON. It is NOT locked until:
- [ ] User has approved it at the ONE checkpoint (not mid-build)
- [ ] Every ambiguity is resolved in writing, not in code assumptions
- [ ] "What this build will NOT include" is explicitly stated
- [ ] Success criteria are defined (how will we know it's done?)

**Spec format (locked fields — Saanvi cannot leave these blank):**
```json
{
  "projectId": "<SHA-based 12-char hash of git remote URL>",
  "name": "<user-provided project name>",
  "description": "<one sentence>",
  "features": ["<specific feature>", ...],
  "outOfScope": ["<explicitly excluded>", ...],
  "stack": {
    "frontend": "next14+ts+tailwind+shadcn",
    "backend": "express+ts",
    "database": "supabase+postgres",
    "auth": "clerk",
    "deploy": "vercel+railway"
  },
  "successCriteria": ["<measurable criterion>", ...],
  "qualityProfile": "<from user account default or gathered conversationally>"
}
```

---

## Gate 3: Team Contracts (D23 — sprint contracts via files)

Arjun proposes "done" criteria for each parallel team. Each team
reviews their contract. Code starts ONLY after all contracts are agreed
via files — not verbally, not assumed.

```markdown
# Contract: {projectId}-backend (Shubham)
Done when:
- [ ] All endpoints in API contract respond with correct shapes
- [ ] Auth middleware validates Clerk JWT on all protected routes
- [ ] bun test passes: 0 failures
- [ ] bun run build exits 0

# Contract: {projectId}-frontend (Aanya)
Done when:
- [ ] All user flows in spec are navigable in the browser
- [ ] npx jest passes: 0 failures
- [ ] npx next build exits 0
- [ ] Playwright screenshot confirms critical flows visually

# Contract: {projectId}-database (Pranav)
Done when:
- [ ] All tables in schema outline exist
- [ ] RLS policies active on all user-data tables
- [ ] All migrations run clean on fresh DB
- [ ] bun test src/db/ passes
```

---

## Gate 4: Independence Check (required before parallel dispatch)

Before Arjun dispatches parallel agents, verify:
- [ ] API contract specifies every endpoint: method, path, request
      shape, response shape — no "TBD" fields
- [ ] DB schema outline specifies every table and relation
- [ ] Confirmed: no agent needs to read another's in-progress code

If either is incomplete: finish it. One incomplete contract causes
merge conflicts and wasted parallel work.

---

## Gate 5: Team Briefings

**Dev team (Shubham/Aanya/Pranav):** their locked contracts (Gate 3)
serve as their brief. They do not need more.

**Adversarial QA (Navya/Karan/Deepika):** brief BEFORE build, not
after:
- What type of project is this? (determines eval mode per D20)
- Full-stack with UI → Playwright live testing
- API-only → code-review + test suite only
- Static/design → screenshot review
- Any specific attack surface to watch for? (e.g., user-uploaded files,
  payment flows, admin privilege escalation paths)

**Red Team (Vikram/Priya/Raj/Surya):** brief at Gate 1, not at
deployment:
- What new endpoints/surfaces will appear in NexSidi's OWN platform
  after this build? (Not the generated app — NexSidi's infrastructure)
- What changes to IAM, containers, or cloud config?
- Raj: any new places where user-provided content reaches an agent?

**Blue Team (Ananya/Kunal/Divya/Rohan):** update their monitoring
config BEFORE deployment, not after:
- New endpoints to watch
- New alert thresholds if the project changes scale
- New WAF rules if the attack surface changes

---

## What Happens If a Gate Fails

| Gate | Fail condition | Action |
|---|---|---|
| 1. Feasibility | Stack gap found | Tilotma flags to user BEFORE spec |
| 2. Spec Lock | Ambiguity remains | Saanvi asks the one clarifying question |
| 3. Team Contracts | Agent disagrees with "done" criteria | Arjun negotiates — never starts build with unresolved contracts |
| 4. Independence | Incomplete API contract | Complete the contract. No parallel dispatch. |
| 5. Briefings | Red/Blue team not briefed | Brief them. Never surprise them at deploy time. |

---
*Source: CLAUDE.md architectural decisions D21 (spec compliance first),
D22 (ambitious planner), D23 (sprint contracts via files), D25
(default-FAIL), D33/D34 (approval model), and the 8-layer security
model. All gates derived from first-principles architecture.*
