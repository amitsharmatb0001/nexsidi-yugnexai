---
name: nexsidi-master-workflow
description: Use at the start of every session working on NexSidi, before any code is written, and whenever resuming work after a context reset.
---

# NexSidi Master Workflow — Official Anthropic Hook Mechanism
## Pre-Production Philosophy, Now With Exact Primary-Source Implementation

## Always Start Here (verbatim convention, source: anthropics/cwc-long-running-agents)

Before doing anything else, read `PROGRESS.md`. It is the handoff note
from the previous session. If it doesn't exist, create it now with
exactly four sections, left empty:

```markdown
## Done
## In progress
## Next
## Notes
```

Then run `git log --oneline -10` to see what was just committed, and run
the project's smoke test (`bun test` / `bun run build`) once to confirm
you're starting from a working tree, not a broken handoff.

## One Feature At A Time

Work on exactly one item from `PROGRESS.md` per session. Finish it
(tests passing, evidence verified) before starting another. If given a
new task mid-session, add it to `PROGRESS.md` and finish the current
item first.

## Proof Before Passing — exact 3-step, hook-enforced

A test is only "passing" after:
1. Run it against the live app (Playwright screenshot or equivalent)
2. **Open the resulting screenshot or console log with the Read tool**
   — not generate it and assume, actually read it
3. Confirm it shows what it should

This is enforced structurally, not just by instruction. The real
mechanism (adapt to NexSidi's TypeScript harness — see below):

```bash
# track-read.sh — fires on every Read tool call
# Records evidence files (screenshots, console logs) opened this session
log="${VERIFY_READ_LOG:-./.claude/.evidence-reads}"
path=$(cat | python3 -c 'import json,sys; print(json.load(sys.stdin).get("tool_input",{}).get("file_path",""))')
case "$path" in
  *screenshots/*|*-console.txt|*-result.txt|*.png) [ -f "$path" ] && echo "$path" >> "$log" ;;
esac

# verify-gate.sh — fires on every Write/Edit to the results file
# Denies the write unless evidence was read THIS session, then consumes it
log="${VERIFY_READ_LOG:-./.claude/.evidence-reads}"
results="${RESULTS_FILE:-test-results.json}"
if [ ! -s "$log" ]; then
  echo '{"decision":"block","reason":"Cannot modify results file: no evidence Read this session. Open evidence with Read tool first."}'
  exit 0
fi
: > "$log"   # consume — next write needs FRESH evidence
```

**Known honest limitation (stated directly in the source):** this only
hooks Write/Edit — a Bash `sed`/`jq` rewrite bypasses it; path matching
is basename-only; any evidence read unlocks any result row, not
specifically the one being marked. **NexSidi's TypeScript equivalent in
`nexsidi-agent-tools` must close these gaps** — validate the evidence
file corresponds to the SPECIFIC feature/finding being marked, not just
any evidence existing.

## The Evaluator — exact subagent definition

```yaml
---
name: evaluator
description: Skeptical second-opinion reviewer. Reads the diff and the
  builder's evidence, then returns PASS or NEEDS_WORK with specific
  findings. Has no Write/Edit tools.
tools: Read, Glob, Grep, Bash
---
```

**Exact 4-step process, verbatim:**
1. Read the spec or acceptance criteria for the feature under review
2. Run `git diff` against baseline to see exactly what changed
3. Open every screenshot/console log and look at what they ACTUALLY
   show, not what filenames imply — file fails to open = treat as
   missing evidence
4. Decide

**The core principle:** "Plausibility is not correctness. A diff that
looks reasonable paired with a screenshot that shows a broken layout is
NEEDS_WORK." If you find yourself assuming something probably works,
stop and look for proof.

**Output contract:** bare word `PASS` or `NEEDS_WORK` on its own line
first (so a wrapper can parse it), then: PASS = one line of convincing
evidence; NEEDS_WORK = bullet list of specific, fixable findings.

**"Do not offer to fix anything yourself."** Strict separation —
evaluator only critiques, never suggests or implements fixes.

## Operator Controls — kill switch + steering

```bash
# kill-switch.sh — halts EVERY tool call while AGENT_STOP file exists
if [ -e "${AGENT_STOP_FILE:-./AGENT_STOP}" ]; then
  echo '{"decision":"block","reason":"Kill switch engaged. Remove AGENT_STOP to resume."}'
fi

# steer.sh — one-shot mid-run redirect via STEER.md
f="${AGENT_STEER_FILE:-./STEER.md}"
if [ -s "$f" ]; then
  note=$(cat "$f")
  echo "{\"decision\":\"block\",\"reason\":\"OPERATOR STEERING: $note\n\nPause, incorporate this guidance, then continue toward the feature goal.\"}"
  : > "$f"   # clear after delivery — one-shot
fi
```
`touch AGENT_STOP` to halt everything immediately. Write to `STEER.md`
to redirect mid-run without restarting the session. **Both apply
directly to Amit's own Claude Code sessions building NexSidi.**

## Commit Discipline — backstop, not primary

```bash
# commit-on-stop.sh — fires on Stop event
# Uses commit -am (TRACKED files only — screenshots/logs never enter history)
if git rev-parse --git-dir >/dev/null 2>&1; then
  if ! git diff --quiet || ! git diff --cached --quiet; then
    git commit -am "session checkpoint: $(date '+%Y-%m-%d %H:%M')"
  fi
fi
```
This is a backstop. The agent is expected to `git add` and commit new
files itself at meaningful checkpoints per the convention above — this
hook only catches what's still uncommitted at session end. Check `git
log` periodically rather than relying on this alone.

## Exact Hook Wiring (settings.json — the real registration pattern)

```json
{
  "hooks": {
    "PreToolUse": [
      { "matcher": "*", "hooks": [{ "type": "command", "command": ".claude/hooks/kill-switch.sh" }, { "type": "command", "command": ".claude/hooks/steer.sh" }] },
      { "matcher": "Read", "hooks": [{ "type": "command", "command": ".claude/hooks/track-read.sh" }] },
      { "matcher": "Write|Edit", "hooks": [{ "type": "command", "command": ".claude/hooks/verify-gate.sh" }] }
    ],
    "Stop": [{ "hooks": [{ "type": "command", "command": ".claude/hooks/commit-on-stop.sh" }] }]
  }
}
```
kill-switch + steer run on EVERY tool call. track-read only on Read.
verify-gate only on Write|Edit. commit-on-stop on session Stop.

## Claude Code's Built-In Alternative: `/goal`

Claude Code ships a native completion-checker command — a separate fast
model checks a stated condition after every turn until met:
```
/goal every feature in PROGRESS.md is implemented, committed, and its tests pass
```
Works in interactive Claude Code, `claude -p` headless, and Remote
Control, with zero hook files needed. **Worth using directly for
Amit's own NexSidi development sessions** rather than always
hand-rolling the custom hook set above — reserve the custom hooks for
when the default-FAIL evidence enforcement specifically is needed.

## Watching A Long Run (no dashboard needed)

```bash
watch -n 2 'tail -20 PROGRESS.md'                          # its own notes
watch -n 5 'git log --oneline -8'                          # work saved
watch -n 5 'find screenshots -name "*.png" | tail -5'      # what it sees
watch -n 2 'wc -l < .claude/.evidence-reads 2>/dev/null'   # evidence reads
```

## Adapting To NexSidi's Own 12-Agent Harness

These are bash hooks for Claude Code sessions — they govern how Amit
(via Claude Code) builds NexSidi. NexSidi's own internal agents
(Tilotma, Shubham, etc.) run as API calls to DeepSeek/Kimi/MiniMax, not
inside Claude Code, so they cannot use these literal hook files. **The
PATTERN still applies and must be reimplemented in TypeScript** within
`nexsidi-agent-tools`'s harness execution flow:
- Default-FAIL contract → `nexsidi-agent-tools`'s structured approval objects
- Fresh-context evaluator → Navya/Karan/Deepika already run with isolated context, confirmed correct
- Agent-maintained handoff → maps to NexSidi's own typed `AgentOutput` + SHA-256 chain (Patent Claim 1)
- Kill switch → maps to the PRIVILEGED-class `pending_human` gate already in `nexsidi-agent-tools`

## What This Skill Forbids

1. Skipping the PROGRESS.md read at session start
2. Marking any test/feature "passing" without having Read the actual evidence file
3. Working on more than one PROGRESS.md item per session
4. Evaluator suggesting or implementing fixes — critique only
5. Relying on commit-on-stop as the primary commit mechanism rather than the backstop it is

---
*Source: anthropics/cwc-long-running-agents (official, full repo read —
all 5 hooks, evaluator.md, settings.json, README) + anthropics/
claude-quickstarts autonomous-coding (cross-referenced). This is primary
Anthropic source code, not a third-party interpretation.*
