---
name: nexsidi-banner-design
description: Use when creating banners for YugNex/NexSidi social media, advertising, website hero sections, or event materials.
allowed-tools:
  - Bash
  - Read
---

# NexSidi Banner Design — Social, Ads, Website Heroes
## Source: ui-ux-pro-max `.claude/skills/banner-design/SKILL.md`

## Platform Size Quick Reference

| Platform | Type | Size (px) | Aspect |
|---|---|---|---|
| LinkedIn | Personal banner | 1584 × 396 | 4:1 |
| Twitter/X | Header | 1500 × 500 | 3:1 |
| Instagram | Story | 1080 × 1920 | 9:16 |
| Instagram | Post | 1080 × 1080 | 1:1 |
| YouTube | Channel art | 2560 × 1440 | 16:9 |
| Facebook | Cover | 820 × 312 | ~2.6:1 |
| Website | Hero | 1920 × 600-1080 | ~3:1 |
| Google Ads | Leaderboard | 728 × 90 | 8:1 |
| Google Ads | Med Rectangle | 300 × 250 | 6:5 |

## Art Direction Styles (for YugNex brand)

| Style | Fits when |
|---|---|
| Minimalist | SaaS/tech announcements, white space, 1-2 colors |
| Bold Typography | Milestone announcements, product launches |
| Gradient | Modern/tech feel, mesh gradients, chromatic blends |
| Geometric | Technical content, grid-based, abstract patterns |
| Glassmorphism | App/SaaS feature showcases |

## Workflow

**Step 1: Gather requirements**
- Purpose: social cover / ad / website hero / event?
- Platform + dimensions
- Headline, subtext, CTA, logo placement
- Quantity of options (default: 3 art direction variants)

**Step 2: Art direction research**
Use `nexsidi-ui-ux` → domain search for style references:
```bash
python3 skills/ui-ux-pro-max/scripts/search.py \
  "saas developer tool banner" --domain style
```

**Step 3: Design in HTML/CSS**
- Use exact platform dimensions
- Safe zone: critical content in central 70-80% of canvas
- Max 2 typefaces, single CTA, 4.5:1 contrast ratio minimum
- All colors via brand tokens (`var(--color-primary)`) — never hardcoded hex
- Inject brand context first: `node scripts/inject-brand-context.cjs`

**Step 4: Export to PNG**
Serve the HTML file locally, then screenshot at exact dimensions.

## Design Rules — Non-Negotiable

- Safe zones: all critical content stays in the central 70-80%
- One CTA per banner. Bottom-right. Minimum 44px height. Action verb.
- Max 2 fonts. Min 16px body. Min 32px headline.
- Text coverage under 20% for ads (Meta penalizes heavy-text ads)
- 4.5:1 contrast ratio minimum for all text

## YugNex Brand Applied

- Primary palette: black/gold — always the anchor
- Never use agent names or internal architecture references in banner copy
- All external copy respects the confidentiality rule: "AI-powered
  software builder" yes, "12-agent pipeline" never
- Sanskrit morphing animation element available for digital banners
  (not static exports — include in HTML CSS animation only)

---
*Source: ui-ux-pro-max `.claude/skills/banner-design/SKILL.md` and
`references/banner-sizes-and-styles.md`, read in full.*
