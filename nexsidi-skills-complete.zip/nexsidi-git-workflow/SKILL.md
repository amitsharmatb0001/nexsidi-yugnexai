---
name: nexsidi-git-workflow
description: Use when starting feature work that needs isolation from current workspace, or when implementation is complete and you need to merge, PR, or clean up — covers both worktree setup and branch completion.
allowed-tools:
  - Bash
  - Read
---

# NexSidi Git Workflow — Worktrees + Branch Completion
## Source: Superpowers `using-git-worktrees` + `finishing-a-development-branch`

## Part 1: Setting Up an Isolated Workspace

**Announce first:** "Using nexsidi-git-workflow to set up isolated workspace."

### Step 0: Detect Existing Isolation First

```bash
GIT_DIR=$(cd "$(git rev-parse --git-dir)" 2>/dev/null && pwd -P)
GIT_COMMON=$(cd "$(git rev-parse --git-common-dir)" 2>/dev/null && pwd -P)
# Also check: not inside a submodule
git rev-parse --show-superproject-working-tree 2>/dev/null
```

If `GIT_DIR != GIT_COMMON` (and not a submodule): already in a linked
worktree. Skip to Step 2. Never create a nested worktree.

### Step 1: Create Worktree (only if Step 0 shows normal repo)

NexSidi uses `.worktrees/` at project root. Verify it's ignored:
```bash
git check-ignore -q .worktrees
```
If NOT ignored: add `.worktrees/` to `.gitignore` and commit first.

**Parallel agent convention (Shubham/Aanya/Pranav):**
```bash
# Per CLAUDE.md architectural decision for parallel execution
git worktree add /workspace/{projectId}-shubham  feat/{projectId}-backend
git worktree add /workspace/{projectId}-aanya    feat/{projectId}-frontend
git worktree add /workspace/{projectId}-pranav   feat/{projectId}-database
```

These paths keep overlapping writes structurally impossible. Conflicts
only surface at merge time, where they're visible and resolvable.

### Step 2: Project Setup

```bash
if [ -f package.json ]; then bun install; fi   # NexSidi uses Bun
if [ -f Cargo.toml ]; then cargo build; fi      # Rust sandbox layer
```

### Step 3: Verify Clean Baseline

```bash
bun test    # or: bun run build && bun test
```

If tests fail: report failures and ask whether to proceed.
Never start feature work from a broken baseline.

---

## Part 2: Finishing a Development Branch

**Announce first:** "Using nexsidi-git-workflow to complete this work."

### Step 1: Verify Tests Pass

```bash
bun test && bun run build && bun run typecheck
```

If tests fail: fix them before offering merge options. Never proceed
with failing tests.

### Step 2: Detect Environment

```bash
GIT_DIR=$(cd "$(git rev-parse --git-dir)" 2>/dev/null && pwd -P)
GIT_COMMON=$(cd "$(git rev-parse --git-common-dir)" 2>/dev/null && pwd -P)
```

### Step 3: Present Options — Exactly These, No Others

**Normal repo or named-branch worktree:**
```
Implementation complete. What would you like to do?

1. Merge back to main locally
2. Push and create a Pull Request
3. Keep the branch as-is (I'll handle it later)
4. Discard this work

Which option?
```

**Detached HEAD (externally managed):**
```
1. Push as new branch and create a Pull Request
2. Keep as-is (I'll handle it later)
3. Discard this work
```

### Step 4: Execute Choice

**Option 1 — Merge locally:**
```bash
MAIN_ROOT=$(git -C "$(git rev-parse --git-common-dir)/.." rev-parse --show-toplevel)
cd "$MAIN_ROOT"
git checkout main && git pull
git merge <feature-branch>
bun test   # verify on merged result BEFORE cleanup
# Only after merge success: git worktree remove + git worktree prune
git branch -d <feature-branch>
```

**Option 2 — PR:** Push branch. Do NOT clean up worktree — user needs
it alive for PR iteration.

**Option 4 — Discard:** Require typed "discard" confirmation.
`git branch -D` (force delete) only after confirmation.

### Cleanup Rule (Options 1 and 4 only)

Only remove worktrees that NexSidi created (path under `.worktrees/`):
```bash
cd "$MAIN_ROOT"
git worktree remove "$WORKTREE_PATH"
git worktree prune   # self-healing: clears stale registrations
```

Never remove worktrees you didn't create.

## Never

- Create a worktree when already in one (Step 0 check is mandatory)
- `git worktree remove` from inside the worktree being removed
- Delete the branch before removing the worktree
- Proceed with failing tests
- Merge without re-running tests on the merged result

---
*Source: Superpowers `skills/using-git-worktrees/SKILL.md` and
`skills/finishing-a-development-branch/SKILL.md`, both read in full.
NexSidi parallel-agent paths applied from CLAUDE.md Part 1.*
