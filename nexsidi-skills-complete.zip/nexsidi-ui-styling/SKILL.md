---
name: nexsidi-ui-styling
description: Use when building React/Next.js UI components, implementing design systems, adding accessible components, customizing themes, or styling generated user-app frontends.
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
---

# NexSidi UI Styling — shadcn/ui + Tailwind CSS
## Source: ui-ux-pro-max `.claude/skills/ui-styling/SKILL.md`

## Core Stack (for Aanya's generated user apps — D2)

```
Component layer:  shadcn/ui (Radix UI primitives + copy-paste)
Styling layer:    Tailwind CSS (utility-first, build-time)
Framework:        Next.js 14 App Router (Aanya's stack)
```

This is for **generated user-app frontends**, not NexSidi's own
internal platform.

## Setup (generated app bootstrap)

```bash
# Initialize shadcn/ui (also configures Tailwind)
npx shadcn@latest init

# Add components as needed
npx shadcn@latest add button card dialog form table
```

## Component Patterns — Common Cases

**Form with validation (React Hook Form + Zod):**
```tsx
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Form, FormField, FormItem, FormLabel,
         FormControl, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
})
```

**Responsive layout with dark mode:**
```tsx
<div className="min-h-screen bg-white dark:bg-gray-900">
  <div className="container mx-auto px-4 py-8">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
```

## Token System — Use Variables, Never Raw Hex

```css
/* CORRECT */
background: var(--color-primary);
font-family: var(--typography-font-heading);

/* WRONG — hardcoded, breaks theming */
background: #2563EB;
font-family: 'Inter';
```

Three-layer token architecture:
```
Primitive (--color-blue-600: #2563EB)
    ↓
Semantic (--color-primary: var(--color-blue-600))
    ↓
Component (--button-bg: var(--color-primary))
```

## Accessibility Rules (Radix UI + shadcn enforces most, these are additional)

- Focus states on all interactive elements
- Keyboard navigation for all flows
- Screen reader labels on icon-only buttons
- 4.5:1 contrast ratio minimum (same as banner-design rule)
- Semantic HTML — `<button>` for actions, `<a>` for navigation

## Dark Mode

```tsx
// Install next-themes
npm install next-themes

// Wrap app
<ThemeProvider attribute="class" defaultTheme="system">

// Use dark: variant in Tailwind
className="bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
```

## Best Practices

1. Composable primitives over monolithic components
2. Utility-first: write Tailwind classes directly, extract to component
   only when truly repeated (3+ times, not 2)
3. Mobile-first: `md:`, `lg:` prefixes layer on top of base styles
4. Never dynamic Tailwind class names (`text-${color}` doesn't work —
   Tailwind purges classes it can't see statically)
5. TypeScript: full type safety on all component props

## References (load on demand)

| Topic | File |
|---|---|
| Full component catalog | `references/shadcn-components.md` |
| Theming + dark mode | `references/shadcn-theming.md` |
| Accessibility patterns | `references/shadcn-accessibility.md` |
| Core Tailwind utilities | `references/tailwind-utilities.md` |
| Responsive design | `references/tailwind-responsive.md` |
| Config + custom tokens | `references/tailwind-customization.md` |

---
*Source: ui-ux-pro-max `.claude/skills/ui-styling/SKILL.md`, read in
full. NexSidi generated-app stack applied from CLAUDE.md Part 1 (D2).*
