---
name: nexsidi-generated-stack
description: Use when Aanya, Shubham, or Pranav are building a generated user app — defines the standard stack, why it's different from NexSidi's own, and all conventions for output code.
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
---

# NexSidi Generated Stack — Standard Output for User Apps
## Source: CLAUDE.md Part 1 (D2) + Part 2 (D2, D5, D6, D7, D8)

## The Stack (D2 — decided, do not change without Tilotma + Amit approval)

```
Frontend:  Next.js 16.2 + TypeScript + Tailwind CSS + shadcn/ui
Backend:   Node.js + Express + TypeScript
Database:  PostgreSQL 16 (local Docker container)
Auth:      Clerk
Deploy:    Docker Compose → localhost:3000 (NOT Vercel / Railway / Supabase)
```

⚠️  NOT Next.js 14 — it is EOL since October 2025
⚠️  NOT Next.js 15 — 16.2 is current stable (June 2026)
⚠️  NOT Supabase — local PostgreSQL 16 container only
⚠️  NOT Vercel or Railway — Docker Compose local delivery only

## Why This Is DIFFERENT From NexSidi's Own Stack

NexSidi's platform uses Bun + Hono. Generated apps use Express. This
is a deliberate architectural decision (D2), not an oversight.

**Reason:** Generated code must be maintainable by ANY developer the
user later hires. Express is universally known — any Node.js developer
can maintain it. Bun + Hono is cutting-edge and less universally known.
Different stacks by deliberate design.

**Never use Bun or Hono in generated user app code.** Ever.

## Deployment Model

User receives:
```
✓ http://localhost:3000 — opens in Chrome, works
✓ docker-compose.yml — one command starts everything
✓ Source code ZIP + GitHub repo (private)
✓ PRD document (from Saanvi's locked spec)
✓ Feature list (plain language)

✗ Any cloud-hosted URL — local only for now
✗ Agent names or architecture (never)
✗ QA findings (internal)
✗ Pipeline logs (internal)
```

## Database Model (D5)

Each generated project gets its **own PostgreSQL 16 container** via
Docker Compose. Not shared, not Supabase, not RLS. Simple per-project
isolation: each project has its own database name, its own schema, its
own container.

```yaml
# In docker-compose.yml
postgres:
  image: postgres:16-alpine
  environment:
    POSTGRES_DB: project_{projectId}
    POSTGRES_USER: appuser
    POSTGRES_PASSWORD: apppassword
  volumes:
    - ./db/migrations/0000_initial.sql:/docker-entrypoint-initdb.d/init.sql:ro
```

No RLS, no Supabase auth helpers — auth is handled entirely by Clerk.

## Git Organization (D6)

One GitHub repo per generated project. The GitHub org repo IS the
backup — no separate backup step needed.

```
Naming: {org}/{projectId}-{user-slug}
Example: yugnex/{abc123def456}-restaurant-booking
```

## Database Conventions (D7, D8)

**D7 — No raw SQL via agent harness.** Generated backend code can use
Drizzle ORM or Prisma — typed queries only. Never raw SQL strings
passed as parameters to an agent tool.

**D8 — Expand-contract migrations.** All migrations follow:
```
Step 1: Expand — add new column/table (backward compatible)
Step 2: Backfill — populate existing rows
Step 3: Verify — confirm backfill in production
Step 4: Contract — remove old column (separate migration, separate deploy)
```
Never rename or drop in the same migration as the add.

## Standard Express Backend Structure

```
{project}/
├── src/
│   ├── index.ts          # entry point, port 3000
│   ├── app.ts            # Express app + middleware
│   ├── routes/
│   │   ├── auth.ts       # Clerk webhook + session
│   │   └── {feature}.ts  # one file per domain
│   ├── middleware/
│   │   ├── auth.ts       # Clerk JWT validation
│   │   └── errors.ts     # global error handler
│   └── db/
│       ├── client.ts     # postgres/Drizzle client
│       └── schema.ts     # table definitions (Drizzle or Prisma)
├── tests/
│   └── {feature}.test.ts
├── package.json
└── tsconfig.json
```

## Auth Pattern (Clerk)

```typescript
import { ClerkExpressRequireAuth } from '@clerk/clerk-sdk-node'

// Protect routes
app.use('/api', ClerkExpressRequireAuth())

// Get user in handler
app.get('/api/profile', (req, res) => {
  const userId = req.auth.userId;
  // ...
})
```

## Database Pattern (local PostgreSQL 16)

```typescript
// db/client.ts — Drizzle with postgres.js
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";

const client = postgres(process.env.DATABASE_URL!);
export const db = drizzle(client);
```

```typescript
// db/schema.ts — user data tables always have clerkId for isolation
import { pgTable, text, uuid, timestamp, boolean } from "drizzle-orm/pg-core";

export const tasks = pgTable("tasks", {
  id:        uuid("id").primaryKey().defaultRandom(),
  clerkId:   text("clerk_id").notNull(),   // Clerk user ID for row isolation
  title:     text("title").notNull(),
  dueDate:   timestamp("due_date"),
  completed: boolean("completed").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
```

No RLS — isolation is enforced by `WHERE clerk_id = ?` in every query.
Clerk authenticates the user; the backend extracts `userId` from the JWT
and scopes all queries to it.

## What Users Receive (not more, not less)

```
✓ http://localhost:3000 — working app
✓ docker-compose.yml — one command to start
✓ Source code ZIP + GitHub repo (private)
✓ PRD document (from Saanvi's locked spec)
✓ Feature list (plain language)

✗ Any cloud-hosted URL (local only for now)
✗ Test suite (internal)
✗ QA findings (internal)
✗ Pipeline logs (internal)
✗ Agent names or architecture (never)
✗ Quality scores or iteration count (internal)
```

---
*Source: CLAUDE.md Part 1 (tech stack — generated user apps section)
and Part 2 (D2, D5, D6, D7, D8). Kept strictly separate from
NexSidi's own platform stack per D2.*
