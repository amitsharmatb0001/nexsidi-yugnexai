---
name: nexsidi-generated-stack
description: Use when Aanya, Shubham, or Pranav are building a generated user app — defines the standard stack, why it's different from NexSidi's own, and all conventions for output code.
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
---

# NexSidi Generated Stack — Standard Output for User Apps
## Source: CLAUDE.md Part 1 (D2) + Part 2 (D2, D5, D6, D7, D8)

## The Stack (D2 — decided, do not change without Tilotma + Amit approval)

```
Frontend:  Next.js 14 + TypeScript + Tailwind CSS + shadcn/ui
Backend:   Node.js + Express + TypeScript
Database:  PostgreSQL via Supabase (RLS ALWAYS enabled)
Auth:      Clerk
Deploy:    Vercel (frontend) + Railway (backend) + Supabase (DB)
```

## Why This Is DIFFERENT From NexSidi's Own Stack

NexSidi's platform uses Bun + Hono. Generated apps use Express. This
is a deliberate architectural decision (D2), not an oversight.

**Reason:** Generated code must be maintainable by ANY developer the
user later hires. Express is universally known — any Node.js developer
can maintain it. Bun + Hono is cutting-edge and less universally known.
Different stacks by deliberate design.

**Never use Bun or Hono in generated user app code.** Ever.

## Multi-Tenancy Model (D5)

All user projects share ONE PostgreSQL database with `user_id` columns.
Not separate schemas, not separate databases per user.

```sql
-- Every user-data table has this
user_id TEXT NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
```

Row-Level Security (RLS) is always enabled. Never generate code that
disables RLS or creates a table without an RLS policy.

## Git Organization (D6)

One GitHub repo per generated project. The GitHub org repo IS the
backup — no separate backup step needed.

```
Naming: {org}/{projectId}-{user-slug}
Example: yugnex/{abc123def456}-restaurant-booking
```

## Database Conventions (D7, D8)

**D7 — No raw SQL via agent harness.** Generated backend code can use
Drizzle ORM or Prisma — typed queries only. Never raw SQL strings
passed as parameters to an agent tool.

**D8 — Expand-contract migrations.** All migrations follow:
```
Step 1: Expand — add new column/table (backward compatible)
Step 2: Backfill — populate existing rows
Step 3: Verify — confirm backfill in production
Step 4: Contract — remove old column (separate migration, separate deploy)
```
Never rename or drop in the same migration as the add.

## Standard Express Backend Structure

```
{project}/
├── src/
│   ├── index.ts          # entry point, port 3000
│   ├── app.ts            # Express app + middleware
│   ├── routes/
│   │   ├── auth.ts       # Clerk webhook + session
│   │   └── {feature}.ts  # one file per domain
│   ├── middleware/
│   │   ├── auth.ts       # Clerk JWT validation
│   │   └── errors.ts     # global error handler
│   └── db/
│       ├── client.ts     # Supabase client
│       └── schema.ts     # table definitions
├── tests/
│   └── {feature}.test.ts
├── package.json
└── tsconfig.json
```

## Auth Pattern (Clerk)

```typescript
import { ClerkExpressRequireAuth } from '@clerk/clerk-sdk-node'

// Protect routes
app.use('/api', ClerkExpressRequireAuth())

// Get user in handler
app.get('/api/profile', (req, res) => {
  const userId = req.auth.userId;
  // ...
})
```

## Supabase RLS Pattern

```sql
-- Always create RLS policy immediately after CREATE TABLE
ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;

CREATE POLICY "users can only see their own data"
ON {table}
FOR ALL
USING (auth.uid()::text = user_id);
```

## What Users Receive (not more, not less)

```
✓ Deployed URL (Vercel frontend, Railway backend)
✓ Source code ZIP + GitHub repo access
✓ PRD document (from Saanvi's locked spec)
✓ Feature list (plain language)
✓ User guide

✗ Test suite (internal)
✗ QA findings (internal)
✗ Pipeline logs (internal)
✗ Agent names or architecture (never)
✗ Quality scores or iteration count (internal)
```

---
*Source: CLAUDE.md Part 1 (tech stack — generated user apps section)
and Part 2 (D2, D5, D6, D7, D8). Kept strictly separate from
NexSidi's own platform stack per D2.*
