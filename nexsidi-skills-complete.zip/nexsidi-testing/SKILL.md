---
name: nexsidi-testing
description: Use when implementing any feature or bugfix, before writing implementation code — applies to Aarav, Shubham, Aanya, and Pranav on every task.
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
---

# NexSidi Testing — TDD Iron Law
## Source: Superpowers `test-driven-development` + `testing-anti-patterns.md`

## The Iron Law

```
NO PRODUCTION CODE WITHOUT A FAILING TEST FIRST
```

Write code before the test? Delete it. Start over. No exceptions — not
for "simple" functions, not for config files, not for "I'll add tests
later." Thinking "just this once"? That's rationalization. Stop.

## Red-Green-Refactor — Exact Cycle

**RED:** Write one minimal test. One behavior. Clear name. No "and" in
the name — if "and" appears, split it into two tests. Use real code
paths, not mock behavior.

**Verify RED — mandatory, never skip:**
```bash
bun test path/to/test.ts   # or: npx jest path/to/test.test.ts
```
Confirm: test FAILS (not errors), failure message is expected, fails
because the feature is missing — not because of a typo. Test passes
immediately? You're testing existing behavior. Fix the test.

**GREEN:** Write the simplest code that makes the test pass. Just
enough. No extra features, no "while I'm here" improvements, no YAGNI
violations. Over-engineering here is a red flag.

**Verify GREEN — mandatory:**
```bash
bun test path/to/test.ts
```
All tests must pass. Any regression? Fix it now, not later.

**REFACTOR:** Only after green. Remove duplication, improve names,
extract helpers. Never add behavior during refactor.

## NexSidi Stack Test Commands

```bash
# API layer (Shubham — TypeScript/Bun/Hono)
bun test                          # run all
bun test src/api/routes/auth.test.ts   # specific file

# Frontend (Aanya — Next.js 14)
npx jest src/components/          # component tests
npx jest --testPathPattern=auth   # pattern match

# Database (Pranav — Drizzle ORM)
bun test src/db/                  # migration + query tests

# Generated user-app code (Aarav runs these inside sandbox)
npm test                          # Express/Node generated apps
```

## Testing Anti-Patterns — Never Do These

**Anti-pattern 1: Testing mock behavior instead of real code**
```typescript
// WRONG — tests that the mock exists, not that the component works
expect(screen.getByTestId('sidebar-mock')).toBeInTheDocument();

// RIGHT — test real behavior
expect(screen.getByRole('navigation')).toBeInTheDocument();
```

**Anti-pattern 2: Test-only methods on production classes**
```typescript
// WRONG — destroy() only used in tests, pollutes production class
class Session { async destroy() { ... } }

// RIGHT — use beforeEach/afterEach hooks with existing public API
// or use dependency injection so tests can swap the dependency
```

**Anti-pattern 3: Mocking without understanding the dependency**
Never mock something you don't fully understand. If the dependency is
hard to mock, that's a design signal — the code is too coupled.

## Verification Checklist (before marking ANY task done)

- [ ] Every new function has a test written BEFORE it
- [ ] Watched each test fail for the expected reason
- [ ] Wrote minimal code to pass — nothing extra
- [ ] All tests pass including pre-existing ones
- [ ] Output is clean (no console errors, no warnings)
- [ ] Edge cases and error paths covered
- [ ] No mocks testing mock behavior

Can't check all boxes? You skipped TDD. Delete the code. Start over.

## Bug Fix Rule

Every bug fix starts with a failing test that reproduces the bug.
Never fix bugs without a test — the fix proves nothing and the bug
will return.

## Common Rationalizations to Ignore

| What the agent thinks | Reality |
|---|---|
| "Too simple to test" | Simple code breaks. Test takes 30 seconds. |
| "I'll write tests after" | Tests written after pass immediately. Proves nothing. |
| "Already manually tested" | No record, can't re-run, misses edge cases. |
| "Deleting X hours is wasteful" | Sunk cost fallacy. Unverified code is debt. |
| "Tests-after achieve the same" | Tests-after = "what does this do?" Tests-first = "what should this do?" |

---
*Source: Superpowers `skills/test-driven-development/SKILL.md` and
`skills/test-driven-development/testing-anti-patterns.md`, both read
in full. NexSidi stack commands applied from CLAUDE.md.*
