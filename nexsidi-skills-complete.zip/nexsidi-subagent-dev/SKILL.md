---
name: nexsidi-subagent-dev
description: Use when executing implementation plans with independent tasks — preferred over nexsidi-planning's execute mode whenever subagents are available (D41).
allowed-tools:
  - Bash
  - Read
  - Write
---

# NexSidi Subagent-Driven Development — Preferred Execution Mode
## Source: Superpowers `subagent-driven-development`

## Why This Exists (D41)

`nexsidi-planning`'s execute mode runs tasks inline in one session —
context accumulates, earlier decisions pollute later tasks, no
independent review between steps. This skill is better: fresh
subagent per task, independent task review after each, broad
whole-branch review at the end. D41 states this is PREFERRED when
subagents are available. `nexsidi-planning` execute mode is the
fallback when they're not.

## The Process

```
1. Read plan → note global constraints → create todos for ALL tasks

2. Per task:
   a. Record commit hash BEFORE dispatch (BASE)
   b. Dispatch fresh implementer subagent with:
      - Where this task fits in the project (one sentence)
      - Task brief (requirements, exact values verbatim from spec)
      - Interfaces from earlier tasks this task depends on
      - Report file path + report contract
   c. Implementer → status: DONE / DONE_WITH_CONCERNS /
      NEEDS_CONTEXT / BLOCKED
   d. Run review package (BASE → HEAD), dispatch task reviewer
   e. Reviewer returns: spec ✅ and quality approved?
      → YES: mark task complete in todos + progress ledger
      → NO: dispatch fix subagent → re-review → repeat
   
3. After all tasks: dispatch final whole-branch code reviewer

4. Use nexsidi-git-workflow to finish the branch
```

## Continuous Execution — No Check-ins Between Tasks

Do NOT pause between tasks to ask "should I continue?" Execute all
tasks from the plan without stopping unless:
- BLOCKED status that cannot be resolved
- Ambiguity that genuinely prevents progress
- All tasks complete

"Should I continue?" prompts waste time. The plan was approved — execute it.

## Handling Implementer Status

**DONE:** Generate review package, dispatch task reviewer.

**DONE_WITH_CONCERNS:** Read concerns before proceeding. If about
correctness or scope, address before review. If observations only
("this file is getting large"), note and proceed.

**NEEDS_CONTEXT:** Provide missing context, re-dispatch same model.

**BLOCKED:**
1. Context problem → provide more context, re-dispatch
2. Task too hard → re-dispatch with more capable model
3. Task too large → break into smaller pieces
4. Plan is wrong → escalate to Amit

Never ignore a BLOCKED status. Never force the same model to retry
without changing something.

## Progress Ledger — Required

Conversation memory doesn't survive compaction. Track progress in a
ledger file:

```bash
# Check on session start or resume
cat "$(git rev-parse --show-toplevel)/.nexsidi/sdd/progress.md"
```

When a task's review passes, append one line immediately:
```
Task N: complete (commits <base7>..<head7>, review clean)
```

After any compaction, trust the ledger and `git log` over your own
recollection. Never re-dispatch a task the ledger marks complete.

## Reviewer Rules — What NOT to Put in Reviewer Prompts

- No "check all uses" without a concrete reason
- No "don't flag X" or "treat this as Minor at most" — pre-judging
  findings defeats the independent reviewer
- Global Constraints block = binding requirements verbatim from the
  spec, not the review process rules (those are already in the
  reviewer template)
- Hand reviewer a diff file (BASE to HEAD), not pasted diff text

## Final Whole-Branch Review

Dispatch on the most capable available model. Give it a review package
from `MERGE_BASE` to `HEAD`. If findings come back, dispatch ONE fix
subagent with the complete findings list — not one fixer per finding.

## Model Selection

- Mechanical implementation (isolated function, 1-2 files, complete spec):
  cheapest model
- Integration tasks (multi-file, pattern matching): standard model
- Architecture tasks, final whole-branch review: most capable model
- Always specify the model explicitly — omitting it silently uses the
  session default (usually the most expensive)

---
*Source: Superpowers `skills/subagent-driven-development/SKILL.md`,
read in full. NexSidi progress ledger path and D41 preference applied
from CLAUDE.md.*
