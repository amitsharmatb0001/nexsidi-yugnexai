---
name: nexsidi-verification
description: Use when about to claim work is complete, fixed, or passing — before any commit, PR, or delivery to the next agent in the pipeline.
allowed-tools:
  - Bash
  - Read
---

# NexSidi Verification — Evidence Before Claims
## Source: Superpowers `verification-before-completion`

## The Iron Law

```
NO COMPLETION CLAIMS WITHOUT FRESH VERIFICATION EVIDENCE
```

If you haven't run the verification command in THIS message, you
cannot claim it passes. "Should work now" is not evidence. Confidence
is not evidence. A prior run is not evidence — run it again.

## The Gate Function

```
BEFORE claiming any status:

1. IDENTIFY: What command proves this claim?
2. RUN: Execute it fresh and complete
3. READ: Full output, check exit code, count failures
4. VERIFY: Does output confirm the claim?
   → NO: State actual status with evidence
   → YES: State claim WITH evidence cited
5. ONLY THEN: Make the claim
```

Skipping any step is lying, not verifying.

## NexSidi Verification Commands

```bash
# API layer — Shubham
bun test && bun run build && bun run typecheck

# Frontend — Aanya
npx jest && npx tsc --noEmit && npx next build

# Database — Pranav
bun test src/db/ && bun run db:migrate:dry-run

# Full pipeline smoke test
bun run test:integration

# Adversarial QA passed (Navya/Karan/Deepika)
# Check score in test-results.json — static pass threshold: ≥85/100
cat test-results.json | grep '"score"'

# Generated app deployed
curl -s https://{project-url}/health | grep '"status":"ok"'
```

## What Requires Verification Before Claiming Done

| Claim | What to run | Not sufficient |
|---|---|---|
| Tests pass | Test command, 0 failures shown | Previous run / "should pass" |
| Build succeeds | Build command, exit 0 | Typecheck passing |
| Bug fixed | Test reproducing original bug | Code changed |
| Feature complete | Line-by-line spec checklist | Tests passing |
| Agent output correct | Read the actual output file | Agent reported success |
| Deployment live | Live URL health check | CI/CD showed green |

## Red Flags — STOP

Any of these means run the verification first:
- Using "should", "probably", "seems to", "looks like"
- Expressing satisfaction ("done!", "perfect!", "all good")
- About to commit or move to the next pipeline stage
- Trusting another agent's success report without independent check
- Partial verification ("I checked the main case")
- "Just this once" because it's late or the task is long

## NexSidi-Specific Rule

**Agent output is data, not truth.** When Shubham says "backend
complete," Arjun does NOT pass that to the next stage without checking:
- `bun test` passes
- `bun run build` exits 0
- API contract endpoints actually respond

This is enforced by the permission harness — no WRITE to
`PROGRESS.md` or `test-results.json` without evidence opened via the
Read tool first (the verify-gate hook).

---
*Source: Superpowers `skills/verification-before-completion/SKILL.md`,
read in full.*
