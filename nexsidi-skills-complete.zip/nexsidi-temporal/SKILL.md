---
name: nexsidi-temporal
description: Use when implementing or modifying Temporal workflows for agent pipeline orchestration, long-running task management, or durable execution patterns in NexSidi.
allowed-tools:
  - Read
  - Bash
  - Edit
  - Write
---

# NexSidi Temporal — Durable Workflow Orchestration
## Source: CLAUDE.md Part 1 (tech stack) + general Temporal framework knowledge

## Why Temporal

The NexSidi agent pipeline is a long-running multi-step process that can
take minutes to hours. Steps can fail, models can be rate-limited, the
user's browser tab can close, and the server can restart — none of these
should lose work. Temporal provides durable execution: every step is
checkpointed, retried automatically, and recoverable without manual
intervention.

## Local Development

```bash
# Temporal runs in Docker (already in docker-compose.dev.yml)
# UI at localhost:8088
# Worker connects at localhost:7233
```

Production: Temporal Cloud (managed, no self-hosting overhead).

## Workflow vs. Activity — The Core Distinction

**Workflows** are the orchestration layer — deterministic, no side
effects, no direct API calls. They only call Activities and make
decisions based on their results.

**Activities** do the actual work — LLM calls, DB writes, file
operations, deployments. They can fail and be retried independently
without replaying the whole workflow.

## NexSidi Pipeline Workflow Pattern

```typescript
import { proxyActivities, defineWorkflow } from '@temporalio/workflow';
import type * as activities from '../activities';

const { 
  saanviGenerateSpec,
  arjunDecomposeTask,
  shubhamBuildBackend,
  aanaBuildFrontend,
  pranavMigrateDatabase,
  runAdversarialQA,
  deployToProduction,
} = proxyActivities<typeof activities>({
  startToCloseTimeout: '30 minutes',
  retry: {
    maximumAttempts: 3,
    backoffCoefficient: 2,
    initialInterval: '5s',
  },
});

export async function projectBuildWorkflow(projectId: string): Promise<BuildResult> {
  // Stage 0: Spec lock
  const spec = await saanviGenerateSpec(projectId);
  
  // Stage 1: Decompose + independence check (Arjun)
  const tasks = await arjunDecomposeTask(spec);
  
  // Stage 2: Parallel build (only after independence check passes)
  const [backend, frontend, database] = await Promise.all([
    shubhamBuildBackend(tasks.backend),
    aanaBuildFrontend(tasks.frontend),
    pranavMigrateDatabase(tasks.database),
  ]);
  
  // Stage 3: Adversarial QA gate (Patent Claim 4)
  const qaResult = await runAdversarialQA({ backend, frontend, database });
  if (qaResult.score < 85) {
    // stuck-state detection happens inside runAdversarialQA
    // if escalated, this activity throws → workflow pauses for human
  }
  
  // Stage 4: Deploy (only after QA passes)
  return await deployToProduction({ backend, frontend, database, spec });
}
```

## Activity Implementation Pattern

```typescript
// activities/index.ts
import { Context } from '@temporalio/activity';

export async function shubhamBuildBackend(task: BackendTask): Promise<BackendOutput> {
  const { heartbeat } = Context.current();

  // Heartbeat prevents activity timeout during long LLM calls
  const interval = setInterval(() => heartbeat('still running'), 30_000);
  
  try {
    const result = await callNIMModel('deepseek-v4-pro', task.prompt);
    return processOutput(result);
  } finally {
    clearInterval(interval);
  }
}
```

## HITL (Human-in-the-Loop) Gate Types (D16)

Three patterns, not just binary pause/resume:

```typescript
// Blocking: pipeline pauses, Tilotma pages Amit, timeout defined
await workflowSignal('human-approval', {
  type: 'blocking',
  action: 'deploy-to-production',
  timeout: '1 hour',  // auto-fail if no response
});

// Advisory: pipeline continues, flagged for async review
await workflowSignal('human-review', {
  type: 'advisory',
  finding: qaResult.criticalFindings,
  rollbackWindowMs: 30 * 60 * 1000,  // 30min rollback window
});

// Sampling: random % reviewed, rate adapts to error rate
await workflowSignal('sample-review', {
  type: 'sampling',
  rate: errorRate > 0.05 ? 1.0 : 0.1,  // 100% review if error rate > 5%
});
```

## Kill Switch

```typescript
// touch AGENT_STOP file → all activities stop at next heartbeat check
// write to STEER.md → Tilotma reads on next activity start, redirects
// Both are checked at the start of every activity via Context.current()
```

## What Temporal Does NOT Replace

- The permission harness (nexsidi-sandbox) — Temporal manages
  orchestration; the sandbox manages execution isolation
- The hash chain (nexsidi-context-chain) — every context transfer
  between activities is still SHA-256 hashed and verified
- Manual approval for DESTRUCTIVE/PRIVILEGED actions — Temporal can
  pause for a signal, but the human approval comes through the UI,
  not through Temporal itself

---
*Source: CLAUDE.md Part 1 (tech stack: Temporal for orchestration),
production environment section (Temporal Cloud), and CI/CD pipeline
section. D16 (HITL gate taxonomy) from Part 2.*
