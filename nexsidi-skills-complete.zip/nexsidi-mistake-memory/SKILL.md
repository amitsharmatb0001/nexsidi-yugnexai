---
name: nexsidi-mistake-memory
description: Use when an agent is about to generate code and needs relevant past instincts, or when a pipeline run completes and new patterns should be recorded.
---

# NexSidi Mistake Memory — Hook-Based Instinct Architecture
## Patent Claim 2

## ⚠️ Critical Fix From V2

V2 instructed agents to "query before, update after" as a skill-level
behavior. **This is unreliable.** Per ECC continuous-learning-v2's own
finding: "Skills are probabilistic — they fire ~50-80% of the time based
on Claude's judgment. Hooks fire 100% of the time, deterministically."

**Memory observation/query MUST be a harness-level hook (PreToolUse/
PostToolUse), never a skill instruction an agent might skip.** This is
now implemented in `nexsidi-agent-tools`'s harness execution flow —
`callAgentForJSON` and `executeToolCall` both call into the instinct
store automatically. No agent decision involved.

## The Instinct Model (atomic, confidence-tiered, project-scoped)

```typescript
interface Instinct {
  id: string;
  trigger: string;              // "when writing JWT verification middleware"
  action: string;                // specific, single behavior
  confidence: number;            // 0.3 | 0.5 | 0.7 | 0.9 — see tiers below
  domain: "code-style" | "security" | "performance" | "testing" | "architecture";
  scope: "project" | "global";   // project is DEFAULT
  projectId: string | null;      // 12-char hash, null if global
  outcome: "mistake" | "success";
  evidence: { pipelineId: string; observedAt: string; description: string }[];
  timesObserved: number;
}
```

**Confidence tiers change ENFORCEMENT, not just weight** (per ECC's
exact behavior table — this is new, v2 only varied weight):

| Score | Meaning | Enforcement behavior |
|---|---|---|
| 0.3 | Tentative | Suggested in prompt, not enforced |
| 0.5 | Moderate | Applied when relevant |
| 0.7 | Strong | Auto-approved for application |
| 0.9 | Near-certain | Core behavior — always applied |

Confidence increases when: pattern repeatedly observed, agent's
suggestion wasn't corrected, independent instincts agree. Decreases
when: explicit correction, no observation for an extended period,
contradicting evidence.

## Project Detection (exact priority order)

```typescript
function detectProjectId(context: PipelineContext): { id: string; scope: "project" | "global" } {
  if (context.explicitProjectId) return { id: context.explicitProjectId, scope: "project" };
  if (context.spec?.gitRemoteUrl) {
    return { id: sha256(context.spec.gitRemoteUrl).slice(0, 12), scope: "project" };
  }
  if (context.spec?.repoPath) {
    return { id: sha256(context.spec.repoPath).slice(0, 12), scope: "project" };
  }
  return { id: "global", scope: "global" };
}
```
Same logic NexSidi projects get the same hash across machines (via git
remote URL) — important once NexSidi has CLI mode and multiple devs.

## Data Location (NOT inside the agent's working directory)

```
${XDG_DATA_HOME:-~/.local/share}/nexsidi-instincts/
  projects.json                  # registry: hash → name/spec/createdAt
  instincts/{personal,inherited}/  # global scope
  evolved/{agents,skills,commands}/
  projects/<hash>/
    observations.jsonl
    instincts/{personal,inherited}/
    evolved/
```
Stored OUTSIDE the project workspace deliberately — mirrors ECC's exact
reasoning: keeps memory writes from ever being blocked by the sandbox's
workspace-scope enforcement (nexsidi-agent-tools' `workspace_only` rule).

## Promotion (Project → Global) — exact threshold, corrected from v2

```typescript
const PROMOTION_CRITERIA = {
  minDistinctProjects: 2,
  minAverageConfidence: 0.8,   // v2 incorrectly used 0.6 — corrected
};

async function checkPromotionEligibility(instinct: Instinct): Promise<boolean> {
  const matches = await findInstinctsByTriggerAction(instinct.trigger, instinct.action, { excludeProjectId: instinct.projectId });
  const distinctProjects = new Set([instinct.projectId, ...matches.map(m => m.projectId)]);
  const avgConfidence = [instinct, ...matches].reduce((s, i) => s + i.confidence, 0) / (matches.length + 1);
  return distinctProjects.size >= PROMOTION_CRITERIA.minDistinctProjects
    && avgConfidence >= PROMOTION_CRITERIA.minAverageConfidence;
}
```

## Scope Decision Guide (verbatim categories from ECC, NexSidi-mapped)

| Pattern type | Scope | NexSidi example |
|---|---|---|
| Framework conventions | project | "This project uses Drizzle, not raw SQL" |
| File structure preferences | project | "Tests live in `tests/`, not co-located" |
| Code style | project | "Use Result-type error handling for this stack" |
| Security practices | **global** | "Validate user input before DB write" |
| General best practices | **global** | "Write tests before implementation" |
| Tool workflow preferences | **global** | "Grep before Edit, Read before Write" |
| Git practices | **global** | "Conventional commits, small focused diffs" |

## Background Observer (batched, not real-time — cost control)

```json
{
  "observer": {
    "enabled": true,
    "run_interval_minutes": 5,
    "min_observations_to_analyze": 20
  }
}
```
Mirrors ECC's exact defaults. Don't analyze every single event — batch
every 5 minutes, require 20+ accumulated observations before the
analysis agent (cheap model, e.g. Haiku-tier) runs.

## Why Hooks, Not Skill Instructions (the core architectural rule)

```
PreToolUse hook  → query relevant instincts → inject into agent prompt
PostToolUse hook → capture outcome → append to observations.jsonl
                   (100% reliable, runs regardless of agent judgment)
```
This is implemented in `nexsidi-agent-tools`'s `executeToolCall` —
every tool call automatically triggers observation capture. No agent
ever needs to "remember" to record a mistake.

## What This Skill Forbids

1. Treating memory query/update as something an agent decides to do —
   it is a deterministic hook, never optional
2. Global-scoping an instinct without meeting the 2-project / 0.8-confidence threshold
3. Storing instinct data inside the sandboxed project workspace
4. Real-time per-event analysis — batch per the observer config
5. Confidence increases without new evidence

---
*Source: ECC continuous-learning-v2 (real config.json, instinct-cli.py,
observe.sh hooks read in full) — corrects the threshold and adds the
hook-based architecture fix entirely missing from v2.*
