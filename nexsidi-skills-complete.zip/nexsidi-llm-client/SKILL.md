---
name: nexsidi-llm-client
description: Use when implementing or modifying the LLM routing layer, adding new agents, changing model assignments, or handling rate limits and fallback behavior.
allowed-tools:
  - Read
  - Bash
  - Edit
---

# NexSidi LLM Client — NVIDIA NIM Routing + Ollama Local
## Source: CLAUDE.md Part 1 (LLM Routing section + D4, D14)

## Model Assignment (decided — do not change without Tilotma review)

```
NVIDIA NIM (free dev tier, 40 RPM per model):
  deepseek-v4-pro   → Tilotma, Aanya, Shubham
  minimax-m3        → Saanvi, Deepika
  mistral-nemotron  → Arjun
  kimi-k2-6         → Navya, Karan

Local Ollama (Qwen2.5-Coder 7B Q4_K_M, GPU on Dell G15):
  qwen2.5-coder:7b  → Vanya, Pranav, Aarav, Riya
```

**Why different models for parallel adversarial agents:**
Navya, Karan, and Deepika run simultaneously. Same model on all three
= 120 RPM hitting one 40 RPM limit = guaranteed rate-limit collisions.
Three different models = 120 RPM spread across three limits = no
collisions. This is a hard architectural constraint, not a preference.

**Why Kimi for Navya and Karan:**
The code-review-skill's reference files include Chinese-language content
(TypeScript and performance guides). Kimi K2.6 is a Chinese-origin
model that reads these natively, giving Navya and Karan better coverage
of those reference materials than any other model.

## Client Configuration Pattern

```typescript
interface AgentLLMConfig {
  model: string;
  provider: 'nvidia-nim' | 'ollama';
  endpoint: string;
  maxRetries: number;
  fallbackChain: FallbackTier[];
}

// NVIDIA NIM base URL
const NIM_BASE = 'https://integrate.api.nvidia.com/v1';

// Ollama endpoint (Docker containers access via host.docker.internal)
const OLLAMA_BASE = 'http://host.docker.internal:11434';
```

## 4-Tier Fallback Chain (D14)

Every agent must have a fallback chain — never a hard failure:

```typescript
enum FallbackTier {
  PRIMARY = 'tier1',    // assigned model, full capability
  FALLBACK = 'tier2',   // lighter model, narrowed task scope
  DEGRADED = 'tier3',   // rule-based/template output
  HUMAN = 'tier4',      // human review queue — Tilotma pages Amit
}
```

**Example for Shubham (DeepSeek V4-Pro):**
```typescript
const shubhamFallback: FallbackTier[] = [
  { tier: 'tier1', model: 'deepseek-v4-pro', provider: 'nvidia-nim' },
  { tier: 'tier2', model: 'qwen2.5-coder:7b', provider: 'ollama', note: 'narrowed: one function at a time' },
  { tier: 'tier3', model: null, note: 'template scaffold only, no logic generation' },
  { tier: 'tier4', model: null, note: 'Tilotma → Amit: model unavailable, manual review required' },
];
```

## Circuit Breaker (D15)

```typescript
enum CircuitState { CLOSED, OPEN, HALF_OPEN }

const CIRCUIT_CONFIG = {
  failureThreshold: 3,     // 3 failures in 5 attempts → OPEN
  cooldownMs: 60_000,      // 60 seconds before HALF_OPEN
  testRequest: 1,          // one test request in HALF_OPEN
};
// CLOSED → normal flow
// OPEN → fail immediately, skip to fallback tier
// HALF_OPEN → one test request → success=CLOSED, fail=OPEN
```

## Rate Limit Handling

```typescript
// NVIDIA NIM: 40 RPM per model
// Retry with exponential backoff, max 3 attempts
// If rate-limited after 3 attempts → activate next fallback tier

const rateLimitRetry = {
  maxAttempts: 3,
  baseDelayMs: 1000,
  multiplier: 2,
  // attempt 1: 1000ms, attempt 2: 2000ms, attempt 3: 4000ms
};
```

## Ollama Local Notes

Ollama runs **natively on Windows** (not in Docker) for direct GPU
access. Docker containers reach it via `host.docker.internal:11434`.
The 7B model (Qwen2.5-Coder Q4_K_M) is sufficient for structured/
templated output tasks — Vanya's design queries, Pranav's migration
generation, Aarav's test scaffolding, Riya's deployment configs.

## What NEVER Goes Through the LLM Client

- DESTRUCTIVE or PRIVILEGED actions (D34) — these bypass LLM routing
  entirely and pause for a human
- The `approvedBy` field in any approval record is never a model name —
  it's either `"policy:rule-name"` or a real human account ID (D33)

---
*Source: CLAUDE.md Part 1 LLM Routing section, D4 (routing decision),
D14 (4-tier fallback chain), D15 (circuit breaker). Model assignments
from the 38-agent roster.*
