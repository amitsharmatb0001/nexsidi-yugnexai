---
name: nexsidi-planning
description: Use when given a spec or requirements for a multi-step task and before any code is written — covers both writing the implementation plan and executing it task-by-task.
allowed-tools:
  - Read
  - Write
  - Bash
  - Glob
---

# NexSidi Planning — Write Plans, Then Execute Them
## Source: Superpowers `writing-plans` + `executing-plans`

## Two Modes — Always in This Order

**Mode 1 (Write):** Given a spec, produce a plan. No code yet.
**Mode 2 (Execute):** Given a plan, implement it task-by-task.

Never skip from spec directly to code. The plan is required.

## Writing the Plan

**Announce first:** "Using nexsidi-planning to write the implementation
plan."

### File Map Before Tasks

Before listing tasks, map every file that will be created or modified
and what each one is responsible for. This is where decomposition gets
locked — change it here, not mid-implementation.

- Clear boundaries, well-defined interfaces per file
- Files that change together, live together
- Each file has ONE responsibility
- Smaller focused files over large ones (you reason better about code
  you can hold in context at once)

### Task Right-Sizing

A task = smallest unit with its own test cycle. Fold setup,
scaffolding, and docs into the task that needs them. Split only where
a reviewer could meaningfully reject one task while approving its
neighbor. Each task ends with an independently testable deliverable.

### Plan Document Header — Always Start With This

```markdown
# [Feature Name] Implementation Plan

> **For agentic workers:** Use nexsidi-subagent-dev (preferred) or
> nexsidi-planning execute mode to implement task-by-task.
> Steps use checkbox (- [ ]) syntax for tracking.

**Goal:** [One sentence]
**Architecture:** [2-3 sentences on approach]
**Tech Stack:** [Specific libs/versions]

## Global Constraints
[Project-wide requirements — version floors, naming rules, platform
requirements — one line each, exact values from the spec verbatim.
Every task inherits this section implicitly.]

---
```

### Task Block Format

````markdown
### Task N: [Component Name]

**Files:**
- Create: `exact/path/to/file.ts`
- Modify: `exact/path/to/existing.ts`
- Test: `exact/path/to/file.test.ts`

**Interfaces:**
- Consumes: [exact function names + types from earlier tasks]
- Produces: [exact function names + types later tasks will use]

- [ ] **Step 1: Write the failing test**
```typescript
test('specific behavior', async () => {
  const result = await functionUnderTest(input);
  expect(result).toBe(expected);
});
```
- [ ] **Step 2: Run test, verify it FAILS**
Run: `bun test path/to/file.test.ts`
Expected: FAIL — "functionUnderTest is not defined"

- [ ] **Step 3: Write minimal implementation**
```typescript
export async function functionUnderTest(input: Input): Promise<Output> {
  return expected; // minimal, not over-engineered
}
```
- [ ] **Step 4: Run test, verify it PASSES**
Run: `bun test path/to/file.test.ts`
Expected: PASS

- [ ] **Step 5: Commit**
```bash
git add path/to/file.ts path/to/file.test.ts
git commit -m "feat: [specific description]"
```
````

## Arjun's Planner Specifics (Mar 2026 blog — exact guidance)

The planner takes a 1-4 sentence prompt and expands it into a full
product spec. Three things are required:

**1. Be ambitious about scope.** Conservative planning = underwhelming
output. A one-sentence prompt should become a 10-16 feature spec
spread across multiple sprints — not a minimal-viable interpretation.
"Create a retro game maker" → 16 features across 10 sprints including
sprite animation, AI-assisted level design, sound effects, game export.

**2. Focus on product context and high-level technical design — NOT
granular technical implementation.** If the planner specifies granular
technical details and gets something wrong, errors cascade into the
entire downstream implementation. Constrain agents on the deliverables
to be produced; let them figure out the implementation path as they work.

**3. Find opportunities to weave AI features into the spec.** Every
generated user app should have at least one Claude integration where
it makes sense — an agent that can drive the app's own functionality
through tools. This is a spec-level decision, not an afterthought.

**What Arjun produces:**
- Full product spec with named features
- Visual design language / identity (using `nexsidi-ui-ux` output)
- High-level technical architecture (stack, major components)
- Sprint breakdown (which features in which sprint)
- NOT: specific function signatures, file structures, API endpoint names

### No Placeholders — Plan Failures to Avoid

Never write:
- "TBD", "TODO", "implement later"
- "Add appropriate error handling" (without showing the code)
- "Write tests for the above" (without the actual test code)
- "Similar to Task N" (repeat the code — an agent may read tasks
  out of order)
- Types/functions referenced but not defined anywhere in the plan

### Self-Review After Writing

Look at the spec with fresh eyes and check:
1. **Coverage:** Every spec requirement maps to a task?
2. **Placeholders:** Any of the plan-failure patterns above?
3. **Type consistency:** Function called `lockSpec()` in Task 3,
   `specLock()` in Task 7 = a bug. Find and fix.

Save plans to: `docs/nexsidi/plans/YYYY-MM-DD-<feature>.md`

---

## Executing the Plan

**Announce first:** "Using nexsidi-planning to execute this plan."

**Preferred over this mode:** If subagents are available, use
`nexsidi-subagent-dev` instead. That skill is D41's preferred path.
This mode is the fallback for single-session execution.

### Execution Process

1. **Load and critically review the plan.** Any concerns or gaps?
   Raise them before starting, not mid-task.

2. **Create todos** for all tasks before touching any code.

3. **Per task:** mark in_progress → follow each step exactly →
   run verifications as specified → mark complete.

4. **Stop immediately when blocked.** A blocker sitting more than
   one attempt without resolution is a signal to escalate to Tilotma,
   not to guess.

5. **After all tasks complete:** use `nexsidi-git-workflow` to finish
   the branch.

### Never During Execution

- Skip verifications ("it should work")
- Start implementation on main/master without explicit consent
- Fix a blocker by guessing — stop and ask

---
*Source: Superpowers `skills/writing-plans/SKILL.md` and
`skills/executing-plans/SKILL.md`, both read in full. NexSidi paths
and stack applied from CLAUDE.md.*
