---
name: nexsidi-debugging
description: Use when encountering any bug, test failure, or unexpected behavior, before proposing any fix.
allowed-tools:
  - Bash
  - Read
  - Grep
---

# NexSidi Debugging — Systematic Root Cause First
## Source: Superpowers `systematic-debugging` + `root-cause-tracing.md`

## The Iron Law

```
NO FIXES WITHOUT ROOT CAUSE INVESTIGATION FIRST
```

Random fixes waste time and create new bugs. "Quick patch now,
investigate later" is how bugs compound. If you haven't completed
Phase 1, you cannot propose a fix.

## The Four Phases — Complete Each Before Proceeding

### Phase 1: Root Cause Investigation

1. **Read error messages completely.** Don't skim. Stack traces have
   line numbers and file paths. That information is the answer.

2. **Reproduce consistently.** Can you trigger it reliably? What are
   the exact steps? If not reproducible — gather more data, don't guess.

3. **Check recent changes.** `git log --oneline -10`, `git diff`. What
   changed that could cause this? New dependency? Config change?

4. **Gather evidence across component boundaries.**
   When the NexSidi pipeline has multiple components (API → agent →
   database, or generator → evaluator → sandbox), add diagnostic
   instrumentation at EACH boundary BEFORE proposing fixes:
   ```typescript
   // Log what enters and exits each component
   console.log('[AGENT:Shubham] context received:', JSON.stringify(ctx, null, 2));
   console.log('[AGENT:Shubham] output hash:', computeHash(output));
   ```
   Run once to see WHERE it breaks. Then investigate that specific layer.

5. **Trace data flow backward (root-cause-tracing pattern):**
   Bugs manifest deep in the stack but originate elsewhere. Trace
   backward through the call chain to the original trigger, then fix
   at the source — never at the symptom.
   ```
   Error in Pranav's migration runner
     → called by Arjun's task dispatch
     → called with empty projectId
     → projectId came from Saanvi's spec with a null field
     → fix: Saanvi validation should reject null projectId at spec-lock time
   ```

### Phase 2: Pattern Analysis

Find a working example of the same pattern in the codebase. Compare
it against what's broken. List every difference, however small. Read
reference implementations COMPLETELY — don't skim.

### Phase 3: Hypothesis and Testing

Form ONE hypothesis: "I think X is the root cause because Y." Write
it down. Make the SMALLEST possible change to test it. One variable
at a time. If it doesn't work — form a NEW hypothesis, don't stack
more fixes on top.

### Phase 4: Implementation

1. **Write a failing test reproducing the bug first** — use
   `nexsidi-testing` skill, no exceptions.
2. **Fix the root cause, not the symptom.** One change.
3. **Verify**: test passes, no regressions, output clean.
4. **If 3 fixes have failed:** STOP. This is an architectural problem,
   not a bug. Escalate to Tilotma. Don't attempt fix #4 without that
   conversation.

## Red Flags — Stop and Return to Phase 1

- "Quick fix for now, investigate later"
- "Just try changing X and see"
- "It's probably X, let me fix that"
- "I don't fully understand but this might work"
- Proposing solutions before tracing data flow
- **"One more fix attempt" when 2 already failed**
- Each fix reveals a new problem in a different place (architectural signal)

## NexSidi-Specific Evidence Commands

```bash
# Check which agent's context transfer broke
grep -n "hash mismatch" logs/pipeline.log

# Temporal workflow state
# (check Temporal UI at localhost:8088 for workflow history)

# Sandbox isolation issue?
bun run sandbox:test -- --verbose

# Database migration drift
bun run db:status

# Agent memory corruption?
bun run memory:validate --project <id>
```

---
*Source: Superpowers `skills/systematic-debugging/SKILL.md`,
`skills/systematic-debugging/root-cause-tracing.md`, and
`skills/systematic-debugging/defense-in-depth.md`, all read in full.*
