---
name: nexsidi-context-chain
description: Use when implementing or modifying inter-agent context transfer, the cryptographic hash chain, agent output signing, or automatic rollback — Patent Claims 1, 3, and 7.
allowed-tools:
  - Read
  - Edit
  - Bash
---

# NexSidi Context Chain — Hash Chain + Signing + Rollback
## Patent Claims 1, 3, 7 — Proprietary

## What This Is

Every context transfer between agents in the NexSidi pipeline is
cryptographically chained. This is the core IP that differentiates
NexSidi from every AI coding tool that passes context via simple
string concatenation.

**Claim 1:** SHA-256 hash on every inter-agent context transfer
**Claim 3:** Automatic rollback to last verified state on hash mismatch
**Claim 7:** RSA-SHA256 cryptographic signing of every agent output

## Implementation (TypeScript — active, Rust version is design provenance only)

```typescript
import { createHash, createSign, createVerify } from 'node:crypto'

// Canonicalize context deterministically (key-ordered JSON)
function canonicalize(context: AgentContext): string {
  return JSON.stringify(context, Object.keys(context).sort());
}

// Compute SHA-256 hash of canonicalized context (Patent Claim 1)
function hashContext(context: AgentContext): string {
  return createHash('sha256')
    .update(canonicalize(context))
    .digest('hex');
}

// Sign agent output with RSA-SHA256 (Patent Claim 7)
function signOutput(output: AgentOutput, privateKey: string): string {
  return createSign('RSA-SHA256')
    .update(JSON.stringify(output))
    .sign(privateKey, 'hex');
}

// Verify signature on received context
function verifySignature(output: AgentOutput, sig: string, pubKey: string): boolean {
  return createVerify('RSA-SHA256')
    .update(JSON.stringify(output))
    .verify(pubKey, sig, 'hex');
}
```

## Database Schema (PostgreSQL `context_chain` table)

```sql
CREATE TABLE context_chain (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id    VARCHAR(12) NOT NULL,  -- 12-char SHA-256 prefix of git remote URL (D30)
  session_id    UUID NOT NULL,
  agent_from    TEXT NOT NULL,          -- e.g. 'arjun'
  agent_to      TEXT NOT NULL,          -- e.g. 'shubham'
  context_hash  CHAR(64) NOT NULL,      -- SHA-256 hex
  signature     TEXT NOT NULL,          -- RSA-SHA256 hex
  verified      BOOLEAN NOT NULL DEFAULT false,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## Receiving Agent Verification Sequence

```typescript
async function receiveContext(
  transfer: ContextTransfer,
  expectedSenderPublicKey: string
): Promise<AgentContext> {

  // 1. Verify RSA signature (Patent Claim 7)
  const sigValid = verifySignature(
    transfer.output,
    transfer.signature,
    expectedSenderPublicKey
  );
  if (!sigValid) {
    await rollbackToLastGoodState(transfer.projectId, transfer.sessionId);
    throw new SignatureVerificationError(transfer);
  }

  // 2. Verify hash integrity (Patent Claim 1)
  const computedHash = hashContext(transfer.context);
  if (computedHash !== transfer.contextHash) {
    await rollbackToLastGoodState(transfer.projectId, transfer.sessionId);
    throw new HashMismatchError(transfer, computedHash);
  }

  // 3. Mark verified in chain
  await db.contextChain.update({
    where: { id: transfer.chainId },
    data: { verified: true }
  });

  return transfer.context;
}
```

## Rollback (Patent Claim 3)

```typescript
async function rollbackToLastGoodState(
  projectId: string,
  sessionId: UUID
): Promise<void> {
  // Find last verified context in the chain
  const lastGood = await db.contextChain.findFirst({
    where: { project_id: projectId, session_id: sessionId, verified: true },
    orderBy: { created_at: 'desc' },
  });

  if (!lastGood) {
    // No verified state exists — escalate to Tilotma
    await tilotmaEscalate({ type: 'no-good-state', projectId, sessionId });
    return;
  }

  // Restore from last good state
  await restoreProjectState(projectId, lastGood.id);
  // Log the rollback — immutable audit trail
  await appendAuditLog({ event: 'rollback', from: 'hash-mismatch', to: lastGood.id });
}
```

## Context Budget Compounding (D13)

A 5-agent sequential chain reaches 15,000+ tokens at Agent E.
Four mandatory mitigation strategies:

1. **Summarization compression** — agents summarize previous context
   before passing forward, not pass full history
2. **Structured state object** — each agent reads/writes ONLY its own
   fields in a shared typed state object
3. **External memory store** — large artifacts (files, test results,
   screenshots) stored in PostgreSQL/pgvector and referenced by ID,
   not embedded in the context
4. **Context checkpointing** — every N tokens, checkpoint to DB and
   restart the agent with a compressed handoff

## What NEVER Goes in the Context Chain

- Raw user credentials or payment data
- Agent system prompts (SHA-256 of prompt is logged, not content — Layer 6)
- Red/Blue team findings (separate access-controlled audit log)

---
*Source: CLAUDE.md Part 1 (SHA-256 context chain code block, 5 patent
claims table) and Part 2 (D13 context budget compounding). Proprietary
NexSidi implementation — do not disclose beyond the 10 patent claims.*
