---
name: nexsidi-parallel-agents
description: Use when facing 2+ independent tasks that can run simultaneously without shared state — Arjun dispatching Shubham/Aanya/Pranav in parallel is the primary use case.
allowed-tools:
  - Bash
  - Read
---

# NexSidi Parallel Agents — Dispatch Independent Tasks Simultaneously
## Source: Superpowers `dispatching-parallel-agents`

## When to Use

```
Multiple independent tasks?         → YES, use this
Tasks share state or file locks?    → NO, run sequentially
One failure affects others?         → NO, investigate together first
Agents would write to same files?   → NO, conflict guaranteed
```

**Primary NexSidi use case:** Arjun dispatches Shubham (backend),
Aanya (frontend), and Pranav (database) in parallel after the API
contract and schema outline are fully locked. The independence check
(confirmed in CLAUDE.md) must pass before any parallel dispatch.

## Independence Check — Mandatory Before Dispatch

Arjun must verify both of these before any parallel agent starts:
1. **API contract fully specified** — every endpoint, method, request
   shape, response shape is locked in the contract file
2. **DB schema outline complete** — every table and relation is locked
   — no agent needs to read another agent's generated code to proceed

If either is incomplete: finish it first. Parallel execution on an
incomplete contract generates conflicts at merge time.

## Dispatching in Parallel

Issue ALL dispatch calls in the SAME response — they run concurrently:

```
[Dispatch Shubham] feat/{projectId}-backend — implement auth endpoints
                   per locked API contract at docs/{projectId}/api.md
[Dispatch Aanya]   feat/{projectId}-frontend — implement auth UI
                   per locked API contract + design tokens
[Dispatch Pranav]  feat/{projectId}-database — implement users table
                   per locked schema at docs/{projectId}/schema.md
```

One dispatch per response = sequential. Multiple in same response = parallel.

## Agent Prompt Structure — Each Must Be

**Focused:** One clear domain (backend, frontend, database — never
mixed). An agent with unclear scope causes scope creep into another
agent's territory.

**Self-contained:** All context the agent needs to understand its
task, without inheriting the dispatching agent's full history.

**Specific about output:** What should the agent report back?
Status, what changed, test results — exactly specified.

**Constrained:** "Do NOT modify files outside src/backend/" prevents
an enthusiastic agent from touching Aanya's work.

## After Agents Return

1. **Read each report** — understand what each agent changed
2. **Check for conflicts** — did any agents edit the same files?
   (Should not happen if independence check passed)
3. **Run full test suite** — verify all three codebases together
4. **Spot check** — agents can make systematic errors; read a
   representative sample of generated code

## NexSidi-Specific Rate-Limit Reason

Shubham, Aanya, and Pranav run on different models specifically to
avoid the 40 RPM per-model NVIDIA NIM rate limit during parallel
execution. Same model on all three = 120 RPM hitting one limit =
rate-limit collisions. Different models = 120 RPM effective capacity
spread across limits.

## What Parallel Dispatch Is NOT For

- Investigating related failures (fix one might fix others)
- Tasks where agents need to read each other's output mid-run
- Tasks touching the same files
- Exploratory work where you don't know the full scope yet

---
*Source: Superpowers `skills/dispatching-parallel-agents/SKILL.md`,
read in full. NexSidi independence check and rate-limit rationale
applied from CLAUDE.md Part 1.*
