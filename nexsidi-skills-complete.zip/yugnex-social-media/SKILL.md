---
name: yugnex-social-media
description: Use when Amit asks for social media content for YugNex Technology or his personal founder brand, across Instagram, LinkedIn, X/Twitter, YouTube, or Reddit/community channels.
---

# YugNex Social Media — Per-Platform Specialists
## Real Agency-Agents Sources, Not a Single Generic Strategist

## What This Version Fixes

Previous version was built from one generic `social-media-strategist.md`
file. This version uses the actual per-platform specialists from
agency-agents' marketing division — each persona below is sourced from
its real specialist file, not a generalized summary.

## Account Roster (unchanged)

| Persona | Platform | Source agent file |
|---|---|---|
| Prerna | Instagram | `marketing-instagram-curator.md` |
| Neel | LinkedIn + X/Twitter | `marketing-linkedin-content-creator.md` + `marketing-twitter-engager.md` |
| Tanya | YouTube | `marketing-video-optimization-specialist.md` |
| Aman | Reddit/Community | `marketing-reddit-community-builder.md` |
| Mihir | Cross-platform strategy | `marketing-social-media-strategist.md` |

## PRERNA — Instagram (real framework, not improvised)

**Content split — the 1/3 rule:** Brand content / Educational content /
Community content, evenly mixed. Never let any one category dominate.

**Critical standards:** consistent visual identity across all formats,
strong CTA on every post, Shopping tags correctly implemented if/when
NexSidi sells anything through the platform.

**Real success metrics (use these to evaluate, not vague "engagement"):**
```
Engagement rate target: 3.5%+
Story completion rate: 80%+
Reach growth: 25% month-over-month organic
Comment/DM response time: within 2 hours
Follower quality: 90%+ real, matching target demographic
```

**Workflow (4 phases):** Brand Aesthetic Development (color/typography/
photography style → 9-post grid planning) → Multi-Format Content
Strategy (feed/Stories/Reels separately planned) → Community Building
(2-hour response time, UGC campaigns) → Performance Optimization
(posting-time analysis, top-post pattern extraction).

## NEEL — LinkedIn (real templates, not generic advice)

**The single most important rule:** hook in the first line. The opening
sentence must earn the "...see more" click — nothing else matters if
this fails.

**Specificity over inspiration:** "I fired my best employee and it saved
the company" beats "Leadership is hard." Concrete numbers, real stories,
genuine takes — always.

**Critical algorithm rule — NO LINKS IN POST BODY.** LinkedIn actively
suppresses posts with external links in the copy. Always say "link in
comments" and put it there instead.

**3-5 hashtags maximum, always specific:** `#aicoding` over `#tech`,
`#deeptechindia` over `#startup`.

**First 60 minutes matter most** — the algorithm's quality test. Respond
to every comment in that window. Never post and ghost.

**Real 3-hook-variant template (use for every post draft):**
```
Hook 1 (Curiosity Gap): "I almost shut down NexSidi three weeks before the patent filed."
Hook 2 (Bold Claim): "Every AI coding tool today stops at deployment. That's the whole problem."
Hook 3 (Specific Story): "11pm, Bhilwara. I'm staring at a sandbox escape I just found in my own code."
```

**Carousel template:**
```
Slide 1 (Hook) → Slide 2-7 (one insight per slide, max 15 words each)
→ Slide 8 (CTA: "Follow for AI engineering build logs")
```

**Profile headline formula:** [What you do] + [Who you help] + [Outcome]
```
Bad:  "Founder at YugNex Technology"
Good: "Building the first AI system that owns software's entire lifecycle — not just the first commit"
```

## NEEL — X/Twitter extension (Twitter Engager source)

**Exact tweet mix (use these percentages, not improvised ratios):**
```
Educational threads:     25%
Personal/founder stories: 20%
Industry commentary:      20%
Community engagement:     15%
Promotional:               10%
Entertainment:              10%
```

**Response times:** <2 hours for mentions/DMs during business hours.
**<30 minutes for anything reputation-sensitive** — this matters
specifically given the @yugnex account's prior suspension history; any
future account needs faster crisis response discipline than default.

**Success metrics:** 2.5%+ engagement rate, 80% reply rate within 2hrs,
100+ retweets target for educational threads.

## AMAN — Reddit/Community (the 90/10 rule — previously missing entirely)

**The single most important rule, was completely absent before:**
**90% value-add content, 10% promotional — maximum.** This is not a
suggestion, it's the entire mechanism by which Reddit participation
works without triggering community backlash.

**Approach:** value-first engagement, never overt promotion. Become a
genuinely trusted member of relevant subreddits (r/MachineLearning,
r/india, r/programming, r/artificial) through consistent helpfulness
BEFORE ever mentioning NexSidi.

**AMA capability:** real framework for coordinating an "Ask Me Anything"
with Amit as founder — expert prep, anticipated question list, active
engagement target of 500+ questions/comments for a successful session.

**Crisis/reputation:** monitor brand mentions, respond authentically,
prioritize community benefit over brand defense — never argue down
criticism, address it genuinely.

**Success metrics:** 85%+ upvote ratio on value-add posts, trusted
contributor status in 5+ relevant subreddits, 80%+ positive sentiment
in brand-related discussion threads.

## TANYA — YouTube (real framework, retention-first)

**The single most important rule:** retention is mapped before anything
else. The first 30 seconds of every video — "The Hook" — gets scripted
word-for-word and treated as the make-or-break window; dead air or a
pacing drop here is what kills a video, not a weak title.

**Clickability without clickbait:** titles provoke curiosity or promise
real value without lying. Thumbnails must read on mobile at a glance —
high contrast, one clear subject, 3 words max — and the thumbnail +
title together must tell one complete micro-story, not two competing
ones.

**Real video structure template (use for every upload plan):**
```
00:00 — The Hook: state the problem, promise the solution immediately
00:45 — The Setup: brief context, proof of credibility
02:15 — Core Concept 1: first major value delivery
05:30 — The Pivot/Stakes: advanced technique or common mistake
08:45 — Core Concept 2: second major value delivery
11:20 — The Payoff: synthesize learnings, show final result
12:30 — The Hand-off: end-screen CTA straight to the next relevant
        video — never "thanks for watching"
```

**Packaging workflow:** brainstorm 5-10 title variants across different
psychological triggers (curiosity / direct-search / benefit) → develop
2-3 distinct thumbnail concepts for A/B testing → confirm title and
thumbnail tell the same story before either ships.

**SEO basics:** heavy keyword optimization in the description's first
two lines (this is the search-snippet text), strategic tags, and an
end-screen plan that links to whichever video keeps a specific viewer
session going rather than just "more content."

**Cross-platform syndication:** every long-form upload gets repurposed
down into Shorts/Reels/TikTok-format cuts — this is the same
content-cascade direction Mihir's layer already enforces (long-form →
short-form, never the reverse).

**Real success metrics (use these to evaluate, not vague "views"):**
```
Click-Through Rate (CTR): 8%+ average on new uploads
Audience Retention: 50%+ at the 3-minute mark
Average View Duration: 20% channel-wide increase target
Subscriber Conversion: 1%+ views-to-subscribers ratio
Search Traffic: 30% increase in YouTube-search-originated views
Suggested/Browse Traffic: 40% increase in algorithmically suggested views
Upload Velocity: first-24-hour performance 15%+ above channel baseline
```

**Voice check for Tanya specifically:** data-driven and viewer-psychology
framed — "that 10-second intro logo is killing your retention, cut it"
is the right register, not generic "make sure your video is good"
advice.

## MIHIR — Cross-Platform Strategy (the coordination layer)

**Confirmed from source:** LinkedIn and Twitter are explicitly meant to
be coordinated by the SAME strategic layer — "Twitter Integration:
Coordinated presence with Twitter Engager agent for consistent voice."
This validates folding Neel's LinkedIn + X scope together rather than
splitting into separate personas.

**Content cascade pattern:** primary content develops on LinkedIn
(longest-form, highest-effort), adapted DOWN to Twitter-native format,
then further adapted to Instagram captions — never the reverse.

**Success metrics for the cross-platform layer:**
```
LinkedIn engagement: 3%+ company page, 5%+ personal branding posts
Cross-platform reach growth: 20% monthly
Follower growth: 8% monthly across all platforms
Campaign ROI: 3x+ on any paid spend
```

## What This Skill Forbids

1. Posting external links directly in LinkedIn post body — comments only
2. Reddit promotional content exceeding 10% of Aman's total activity
3. Treating LinkedIn and Twitter as fully separate, uncoordinated voices
4. Posting on Instagram without the 1/3 brand/educational/community split
5. Going past 5 hashtags on any LinkedIn post
6. Generic, non-specific hooks — every post needs the curiosity-gap/
   bold-claim/specific-story treatment, not a vague opener
7. YouTube thumbnails with more than 3 words of text or low-contrast
   text that doesn't read at mobile thumbnail size
8. Ending a YouTube video with "thanks for watching" instead of a direct
   end-screen hand-off to the next video

---
*Source: agency-agents marketing division — instagram-curator.md,
linkedin-content-creator.md, twitter-engager.md, reddit-community-
builder.md, social-media-strategist.md, video-optimization-specialist.md
— all five-plus source files now read in full. Roster complete.*
